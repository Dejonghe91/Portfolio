ProjetGolang
============

Projet Golang pour la matière E-Application du master AIGLE  

Auteurs:  
* Edouard Dejonghe : dejonghe91@gmail.com
* Alexandre Burczy : alexandrebzy16@gmail.com