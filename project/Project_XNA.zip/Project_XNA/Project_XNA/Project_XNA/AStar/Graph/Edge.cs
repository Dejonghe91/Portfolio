﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_XNA
{
    class Edge<Node> : IComparable
    {
        // atribut de classe
        private Node A;
        private Node B;

        //Accesseurs
        public Node nodeA {
            get { return this.A;    }
        }

        public Node nodeB {
            get { return this.B;     }
        }

        public Edge(Node a, Node b) {
            this.A = a;
            this.B = b;
        }

        public override bool Equals(object obj)
        {
            if (obj is Edge<Node>)
            {
                Edge<Node> edge = (Edge<Node>)obj;
                return this.nodeA.Equals(edge.nodeA) && this.nodeB.Equals(edge.nodeB);
            }
            throw new ArgumentException("Object is not a Edge of Node with the good type");
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public int CompareTo(object obj)
        {
            throw new NotImplementedException();
        }

        public bool Contains(Node uneNode) 
        {
            return this.nodeA.Equals(uneNode) || this.nodeB.Equals(uneNode);
        }
    }//fin de la classe
}//fin du namespace
