﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_XNA
{
    class Graph<T>
    {
        private List<Node<T>> graph;

        public Graph() {
            this.graph = new List<Node<T>>();
        }


        public Graph(T root) : base() {
            Add(root, default(T));
        }


        public bool Contains(Node<T> element) {
            return Contains(element.Data);
        }


        public bool Contains(T element) {
            foreach (Node<T> node in this.graph) {
                if (node.Equals(element)) {
                    return true;
                }
            }
            return false;
        }


        public int IndexOf(Node<T> element) {
            return IndexOf(element.Data);
        }


        public int IndexOf(T element) {
            for (int i = 0; i < this.graph.Count; i++) {
                if (this.graph.ElementAt(i).Equals(element)) {
                    return i;
                }
            }
            return -1;
        }


        public void Add(T child, T parent) {
            if (Contains(parent))
            {
                Node<T> p = this.graph.ElementAt(IndexOf(parent));
                Node<T> c = new Node<T>(child, p);
                this.graph.Add(c);
            }
            else {
                this.graph.Add( new Node<T>(child, null) );
            }
        }


        public Stack<T> getPathToRoot(T element) {

            Stack<T> path = new Stack<T>();

             Node<T> ajout = this.graph.ElementAt(IndexOf(element));

            while (ajout.Parent != null) {
                path.Push(ajout.Data);
                ajout = ajout.Parent;
            }

            return path;
        }

    }//fin de la classe
}//fin du namespace
