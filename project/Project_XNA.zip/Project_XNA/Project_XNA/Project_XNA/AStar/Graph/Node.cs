﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_XNA
{
    class Node<T> : IComparable, IEquatable<T>
    {
        private static int idt = 0;
        private int id;
        private Node<T> parent;
        T data;

        public T Data {
            get { return this.data; }
        }

        public Node<T> Parent {
            get { return this.parent; }
        }

        public Node(T data, Node<T> parent){
            this.data = data;
            this.parent = parent;
            this.id = idt++;
        }


        public override bool Equals(object obj)
        {
            if (obj is Node<T>) {
                return this.data.Equals((Node<T>)obj);
            }
            return false;
        }


        public override int GetHashCode()
        {
            return base.GetHashCode();
        }


        public bool Equals(T other)
        {
            return this.data.Equals(other);
        }


        public int CompareTo(object obj)
        {
            if (obj is Node<T>) {
                return this.id - ((Node<T>)obj).id;
            }
            throw new ArgumentException("Object is not a Node<T>");
        }

    }//fin de la classe
}//fin du namespace
