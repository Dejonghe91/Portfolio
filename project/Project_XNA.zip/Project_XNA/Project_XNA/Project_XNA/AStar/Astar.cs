﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_XNA
{
    class Astar
    {
        private Graph<GameModel> graph;     //vues de tous les états du jeu.
        private List<GameModel> ouvert;     //vue des états non traités.
        private List<GameModel> fermer;     //vue des états deja parcourus.     


        public Astar() 
        {
            this.graph = new Graph<GameModel>();
            this.ouvert = new List<GameModel>();
            this.fermer = new List<GameModel>();
        }


        /// <summary>
        /// Use the Astar algorthm to return the solution path using a stack
        /// </summary>
        /// <param name="m">the node to begin with</param>
        /// <returns>the solution path</returns>
        public Stack<GameModel> getSolution(GameModel m) {
            return this.graph.getPathToRoot(this.aetoile(m));
        }


        /// <summary>
        /// The AStar algorithm
        /// </summary>
        /// <param name="n">The node to begin whith</param>
        /// <returns>the solution node</returns>
        public GameModel aetoile(GameModel n) 
        {
            //Placer le noeud initial n dans OUVERT, f∗(n) = 0
            this.ouvert.Add(n);
            this.graph.Add(n, null);    //ajout de la racine du graph

            //tant que OUVERT n’est pas vide faire
            while(this.ouvert.Count > 0 ){
                //1. Rechercher dans Ouvert le noeud ayant le plus faible F∗. Ce noeud, appelée m est placée dans FERME.
                GameModel m = plusPetitHeuristic();
                this.fermer.Add(m);
                this.ouvert.Remove(m);

                List<GameModel> fils = m.Evolve();

                //2. pour chaque ﬁls, notés fi, de m faire
                for (int i = 0; i < fils.Count; i++)
                {
                    GameModel fi = fils.ElementAt(i);
                    //(a) mettre a jour le lien de parentée de fi vers m
                    this.graph.Add(fi, m);

                    //(b) évaluer le noeud fi : si fi = but alors sortir
                    if (fi.isFinish()) {
                        Console.WriteLine(fi);
                        return fi;
                    }
                    
                    //(c) rechercher une occurrence de fi dans OUVERT et FERME
                    int indexOuvert = nbOccur(fi, this.ouvert);
                    int indexFermer = nbOccur(fi, this.fermer);

                    //(d) si aucune occurrence de fi est trouvée, ni dans OUVERT ni dans FERME alors le mettre dans OUVERT
                    if (indexOuvert == 0 && indexFermer == 0) {
                        this.ouvert.Add(fi);
                    }
                    //(e) si une occurrence, notée k, est trouvée dans OUVERT et F∗(k) < F∗(fi) alors ne pas 
                    //       rajouter fi a OUVERT sinon supprimer k de OUVERT et rajouter fi a OUVERT
                    else if (indexOuvert != 0) {
                        GameModel k = this.ouvert.ElementAt(indexOuvert);
                        if (k.getHeuristique() > fi.getHeuristique()) {
                            this.ouvert.Remove(k);
                            this.ouvert.Add(fi);
                        }
                    }
                    //(f) si une occurrence, notée k, est trouvée dans FERME et F∗(k) < F∗(fi) alors ne pas rajouter fi a OUVERT 
                    //       sinon supprimer k de FERME et rajouter fi a OUVERT
                    else if (indexFermer != 0) {
                        GameModel k = this.fermer.ElementAt(indexFermer);
                        if (k.getHeuristique() > fi.getHeuristique()) {
                            this.fermer.Remove(k);
                            this.ouvert.Add(fi);
                        }
                    }
                }//fin du parcours des fils
            }//fin de la boucle de parcours de ouvert
            return null;
        }//fin de la méthode aetoile


        /// <summary>
        /// This méthodes can return the smaller GamModel by the heuristic way
        /// </summary>
        /// <returns>The smaller GameModel</returns>
        private GameModel plusPetitHeuristic() 
        {
            GameModel pp = this.ouvert.ElementAt(0);
            for (int i = 0; i < this.ouvert.Count; i++) 
            {
                if (pp.getHeuristique() > this.ouvert.ElementAt(i).getHeuristique()) 
                {
                    pp = this.ouvert.ElementAt(i);
                }
            }
            return pp;
        }


        /// <summary>
        /// Get the repetition of an element in a list
        /// </summary>
        /// <param name="element">the element to find</param>
        /// <param name="liste">the list to find the element</param>
        /// <returns>if exist inthe list return the index of the element, else return 0</returns>
        private int nbOccur(GameModel element, List<GameModel> liste) {
            foreach (GameModel e in liste)
            {
                if (e.Equals(element))
                {
                    return liste.IndexOf(e);
                }
            }
            return 0;
        }

    }//fin de la classe
}//fin du namespace
