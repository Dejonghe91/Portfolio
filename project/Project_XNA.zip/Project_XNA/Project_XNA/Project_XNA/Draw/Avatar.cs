using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace Project_XNA
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Avatar : DrawableGameComponent
    {
        private SpriteBatch spriteBatch;

        // textures avatar
        private Texture2D monSpriteAvatar;

        // Position de l'avatar
        #region positionAvatar
        private int posAvatarX;
        private int posAvatarY;
        public int X {
            get { return this.posAvatarX; }
        }
        public int Y {
            get { return this.posAvatarY; }
        }
        #endregion

        // Gestion souris
        private MouseState myMouseState;


        public Avatar(Game game): base(game)
        {
            // TODO: Construct any child components here
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here
            // Initialisation des variables du jeu
            this.posAvatarX = 0;
            this.posAvatarY = 0;
            base.Initialize();
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            myMouseState = Mouse.GetState();
            posAvatarX = myMouseState.X;
            posAvatarY = myMouseState.Y;
            base.Update(gameTime);
        }

        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch((this.Game).GraphicsDevice);
            // Chargement de la texture par le content loader (attention : ne pas mettre l'extension)
            this.monSpriteAvatar = ((Game1)this.Game).Content.Load<Texture2D>("Textures/crosshair");
        }

        public override void Draw(GameTime gameTime)
        {
            // TODO: Add your drawing code here

            // Affichage de l'avatar
            this.spriteBatch.Begin();
            this.spriteBatch.Draw(monSpriteAvatar, new Vector2(posAvatarX-(this.monSpriteAvatar.Width/2), posAvatarY-(this.monSpriteAvatar.Height/2)), Color.White);
            this.spriteBatch.End();

            base.Draw(gameTime);
        }

        /// <summary>
        /// know the state of the left mouse button
        /// </summary>
        /// <returns>true is the left mouse button is pressed</returns>
        public bool Pressed()
        {
            return Mouse.GetState().LeftButton == ButtonState.Pressed;
        }

    }
}
