using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Project_XNA
{
    public class maCamera : GameComponent
    {
        #region Position
        public Vector3 Position
        {
            get
            {
                return position;
            }
            set { position = value; }
        }
        Vector3 position;
        #endregion

        #region LookAt
        public Vector3 LookAt
        {
            get{return lookAt;}
            set { lookAt = value; }
        }
        Vector3 lookAt;
        #endregion

        #region Projection
        public Matrix Projection
        {
            get { return Matrix.CreatePerspectiveFieldOfView(MathHelper.ToRadians(45.0f), Game.GraphicsDevice.Viewport.AspectRatio, 1.0f, 10000.0f); }
            set { projection = value; }
        }
        Matrix projection;
        #endregion

        #region LookAt
        public Matrix View
        {
            get { return Matrix.CreateLookAt(Position, LookAt, Vector3.Up); }
            set { view = value; }
        }
        public Matrix view;
        #endregion

        public maCamera(Game game, Vector3 _position, Vector3 _lookAt) : base(game)
        {
            Position = _position;
            LookAt = _lookAt;
        }

        public override void Update(GameTime gameTime)
        {
            //controle de la camera
            if (Keyboard.GetState().IsKeyDown(Keys.Z))
            {
                this.position.Z += 1.0f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.Q))
            {
                this.position.Y += 1.0f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D))
            {
                this.position.Y -= 1.0f;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.S))
            {
                this.position.Z -= 1.0f;
            }

            base.Update(gameTime);
        }

    }//fin de la classe maCamera
}//fin du namespace
