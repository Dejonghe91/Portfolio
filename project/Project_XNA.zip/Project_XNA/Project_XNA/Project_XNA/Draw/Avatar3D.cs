using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace Project_XNA
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Avatar3D : DrawableGameComponent
    {
        // mesh de l'avatar
        private Model modelAvatar;

        // Position de l'avatar
        #region positionAvatar
        private int posAvatarX;
        private int posAvatarY;
        private int posAvatarZ;
        public int X
        {
            get { return this.posAvatarX; }
        }
        public int Y
        {
            get { return this.posAvatarY; }
        }
        public int Z {
            get { return this.posAvatarZ; }
        }
        #endregion

        // Gestion souris
        private MouseState myMouseState;

        private maCamera camera;

        public Avatar3D(Game game, maCamera camera): base(game)
        {
            // TODO: Construct any child components here
            this.camera = camera;
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here
            this.posAvatarX = 0;
            this.posAvatarY = 0;
            this.posAvatarZ = 0;

            base.Initialize();
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            myMouseState = Mouse.GetState();
                posAvatarX = myMouseState.X-(this.GraphicsDevice.DisplayMode.Width/2);
                posAvatarZ = myMouseState.Y-(this.GraphicsDevice.DisplayMode.Height/2);

            //fait sortir le curseur de l'�cran tant que button pressed
            if (myMouseState.LeftButton == ButtonState.Pressed && myMouseState.RightButton == ButtonState.Pressed) {
                posAvatarZ = myMouseState.Y;
            }

            base.Update(gameTime);
        }

        protected override void LoadContent()
        {
            this.modelAvatar = this.Game.Content.Load<Model>("Model/pointeur");
        }

        public override void Draw(GameTime gameTime)
        {
            // TODO: Add your drawing code here

            // Affichage de l'avatar
            foreach (ModelMesh mesh in this.modelAvatar.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.EnableDefaultLighting();
                    effect.PreferPerPixelLighting = true;
                    effect.World = Matrix.CreateTranslation(this.X*0.5f, this.Y*0.5f, this.Z*0.5f);
                    effect.Projection = this.camera.Projection;
                    effect.View = this.camera.View;
                }// fin foreach effect de mesh
                mesh.Draw();
            } // fin foreach mesh



            base.Draw(gameTime);
        }


        /// <summary>
        /// know the state of the left mouse button
        /// </summary>
        /// <returns>true is the left mouse button is pressed</returns>
        public bool Pressed()
        {
            return Mouse.GetState().LeftButton == ButtonState.Pressed ;
        }
    }
}
