using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace Project_XNA
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class DrawModel3D : DrawableGameComponent
    {
        //varaible de classe pour le dessin 3D
        private maCamera camera;
        public Avatar3D cible;

        //model mesh � afficher
        private Model modelPlateau;
        private Model modelTour;
        private Model modelDisque;
        private Model modelSelected;

        //position des tours dans le dessin
        private List<Vector3> pTours;

        //num�ros des tours selectionner pour deplacer un disque
        private List<int> selected;
        private int posSel;

        //gestion a la souris et clavier
        MouseState old_mouseState;
        KeyboardState old_keyboardState;


        public DrawModel3D(Game game): base(game)
        {
            // TODO: Construct any child components here
            this.camera = new maCamera(this.Game, new Vector3(0, 50, 15), new Vector3(0, 0, 0));
            this.Game.Components.Add(this.camera);
            this.cible = new Avatar3D(this.Game, this.camera);
        }


        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here
            //this.history = new Stack<GameModel>();
            this.pTours = new List<Vector3>();
            this.selected = new List<int>(2);

            base.Initialize();
        }


        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // TODO: use this.Content to load your game content here
            this.modelPlateau = this.Game.Content.Load<Model>("Model/plateau");
            this.modelTour = this.Game.Content.Load<Model>("Model/tour");
            this.modelDisque = this.Game.Content.Load<Model>("Model/disque");
            this.modelSelected = this.Game.Content.Load<Model>("Model/selectedSphere");

            base.LoadContent();
        }


        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here

            base.UnloadContent();
        }


        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            //selection des cible pour le deplacement des disque
            if (selected.Count < 3 && this.cible.Pressed() && old_mouseState.LeftButton == ButtonState.Released)
            {
                //on teste si une des tours a pour coordon�e sensiblement la position de l 'avatar 
                //si oui on la selectionne
                for (int i = 0; i < this.pTours.Count; i++)
                {
                    int xcible = this.cible.X;  

                    if ( xcible > ((pTours.ElementAt(i).X*2)-5) && xcible < ((pTours.ElementAt(i).X*2) + 5) )
                    {
                        this.selected.Add(i);   //on stocke l'index (numero) de la tour concern�
                        posSel = xcible;
                    }
                }
            }
            else if(selected.Count == 2){  //sinon les deux tours on �t� selectionner, on procede au mouvement. 
                GameModel ancien = ((Game1)this.Game).hanoii.moveTo(this.selected.ElementAt(0), this.selected.ElementAt(1));
                    if(ancien != null){
                        ((Game1)this.Game).history.Push( ancien );
                        ((Game1)this.Game).nbCoups++;
                    }
                this.selected.Clear();
            }

            //d�selection de l'avatar
            if (Mouse.GetState().RightButton == ButtonState.Pressed && old_mouseState.RightButton == ButtonState.Released) {   //si click gauche on d�s�lectionne
                this.selected.Clear();
            }


            old_keyboardState = Keyboard.GetState();
            old_mouseState = Mouse.GetState();
            base.Update(gameTime);
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Draw(GameTime gameTime)
        {
            drawModelPlateau();     //dessine le plateau de support des tours
            drawModelTour();            //dessine les tours du jeu
            drawDisque();               //dessine les disque sur les tours
            drawSelected();             //dessine les tour selectionn�s

            base.Draw(gameTime);
        }


        /// <summary>
        /// Dessine les disques sur les tours 
        /// </summary>
        public void drawDisque() {
            for (int i = 0; i < ((Game1)this.Game).hanoii.nbTower; i++)//pour chaques tours
            {
                for (int j = 0; j < ((Game1)this.Game).hanoii.GameStruct.ElementAt(i).Count; j++)//pour chaques disques
                {
                    foreach (ModelMesh mesh in this.modelTour.Meshes)
                    {
                        foreach (BasicEffect effect in mesh.Effects)
                        {
                            //pour le positionnement
                            int scale = ((Game1)this.Game).hanoii.GameStruct.ElementAt(i).ElementAt(j).Rayon;
                            float pos = j-(((Game1)this.Game).hanoii.GameStruct.ElementAt(i).Count-(1.5f+((Game1)this.Game).hanoii.nbDisk));
                            //pour le dessin
                            effect.EnableDefaultLighting();
                            effect.PreferPerPixelLighting = true;
                            effect.World = Matrix.CreateScale(scale, scale, 0.5f) * Matrix.CreateTranslation(this.pTours.ElementAt(i).X, this.pTours.ElementAt(i).Y, pos);
                            effect.Projection = this.camera.Projection;
                            effect.View = this.camera.View;
                        }// fin foreach effect de mesh
                        mesh.Draw();
                    } // fin foreach mesh
                }//fin du parcours des disque de la tours
            }//fin du parcour des tours
        }//fin de la m�thode


        /// <summary>
        /// Dessine les tours du jeu
        /// </summary>
        private void drawModelTour() {
            this.pTours.Clear();
            for (int i = 0; i < ((Game1)this.Game).hanoii.nbTower; i++)
            {
                foreach (ModelMesh mesh in this.modelTour.Meshes)
                {
                    foreach (BasicEffect effect in mesh.Effects)
                    {
                        this.pTours.Add(new Vector3(((i) * ((Game1)this.Game).hanoii.nbDisk) * 3, 0, 0));
                        effect.EnableDefaultLighting();
                        effect.PreferPerPixelLighting = true;
                        effect.World = Matrix.CreateScale(1, 1, ((Game1)this.Game).hanoii.nbDisk + 1) * Matrix.CreateTranslation(this.pTours.ElementAt(i));
                        effect.Projection = this.camera.Projection;
                        effect.View = this.camera.View;
                    }// fin foreach effect de mesh
                    mesh.Draw();
                } // fin foreach mesh
            }//fin du parcours des tours
        }


        /// <summary>
        /// Dessine la base rectangulaire plate du jeu
        /// </summary>
        private void drawModelPlateau()
        {
            foreach (ModelMesh mesh in this.modelPlateau.Meshes)
            {
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.EnableDefaultLighting();
                    effect.PreferPerPixelLighting = true;
                    effect.World = Matrix.CreateScale((((Game1)this.Game).hanoii.nbDisk + 2) * ((Game1)this.Game).hanoii.nbTower, ((Game1)this.Game).hanoii.nbDisk + 2, 0.5f) * Matrix.CreateTranslation((((float)(((Game1)this.Game).hanoii.nbTower - 1) / 2)) * (((Game1)this.Game).hanoii.nbDisk * 3), 0, ((Game1)this.Game).hanoii.nbDisk + 1.5f);
                    effect.Projection = this.camera.Projection;
                    effect.View = this.camera.View;
                }// fin foreach effect de mesh
                mesh.Draw();
            } // fin foreach mesh
        }// fin draxModelPlateau



        /// <summary>
        /// dessine une sphere au dessus de la tour selection� par le joueur
        /// </summary>
        private void drawSelected() {
            if (this.selected.Count > 0) {
                for (int i = 0; i < this.selected.Count; i++)
                {
                    foreach (ModelMesh mesh in this.modelSelected.Meshes)
                    {
                        foreach (BasicEffect effect in mesh.Effects)
                        {
                            effect.EnableDefaultLighting();
                            effect.PreferPerPixelLighting = true;
                            effect.World = Matrix.CreateTranslation(posSel, 0, ((Game1)this.Game).hanoii.nbDisk + 2);
                            effect.Projection = this.camera.Projection;
                            effect.View = this.camera.View;
                        }// fin foreach effect de mesh
                        mesh.Draw();
                    } // fin foreach mesh
                }
            }
        }//fin de drawSelected


    }//fin de la classe
}//fin du namespace
