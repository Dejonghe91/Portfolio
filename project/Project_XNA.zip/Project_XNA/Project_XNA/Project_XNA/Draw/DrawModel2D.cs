using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace Project_XNA
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class DrawModel2D : DrawableGameComponent
    {
        public Avatar cible;

        private Texture2D textureDisque, textureTour, texturePlateau;
	    private SpriteBatch spriteBatch;

        private int cX, cY, scaleX, scaleY;
        
        private List<int> selected;
		private List<Vector2> pTours;

        private MouseState oldMouseState;
        private KeyboardState oldKeyboardState;


        public DrawModel2D(Game game): base(game)
        {
            this.cible = new Avatar(this.Game);
        }
        
        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        public override void Initialize()
        {
			this.selected = new List<int>(2);
			this.pTours = new List<Vector2>();

      //Variables cX et cY pour le placement en g�n�ral   
			this.cX = 51;
			this.cY = 30;

			//Variables scaleX et scaleY pour la taille g�n�rale
			this.scaleY = 10;
			this.scaleX = 16;

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            this.texturePlateau = this.Game.Content.Load<Texture2D>("Textures/plateauHanoi");
            this.textureTour = this.Game.Content.Load<Texture2D>("Textures/tourHanoi");
            this.textureDisque = this.Game.Content.Load<Texture2D>("Textures/disqueHanoi");

            base.LoadContent();
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            base.UnloadContent();
        }
				
		/// <summary>
		/// Allows the game component to update itself.
		/// </summary>
		/// <param name="gameTime">Provides a snapshot of timing values.</param>
		public override void Update(GameTime gameTime)
        {
            if (selected.Count < 3 && this.cible.Pressed() && oldMouseState.LeftButton == ButtonState.Released)
			{
		        for (int i = 0; i < this.pTours.Count; i++)
				{
				    int xCible = this.cible.X;
                    
					if (xCible > (pTours.ElementAt(i).X - 15) && xCible < (pTours.ElementAt(i).X + 15))
					{
						this.selected.Add(i);   //on stocke l'index (numero) de la tour concern�
					}
				}
			}					
			else if (selected.Count == 2)  //sinon les deux tours on �t� selectionner, on procede au mouvement. 
			{
                GameModel ancien = ((Game1)this.Game).hanoii.moveTo(this.selected.ElementAt(0), this.selected.ElementAt(1));
                if (ancien != null)
                {
                    ((Game1)this.Game).history.Push(ancien);
                    ((Game1)this.Game).nbCoups++;
                }
                this.selected.Clear();
			}
						
			//d�selection de l'avatar
			if (Mouse.GetState().RightButton == ButtonState.Pressed && oldMouseState.RightButton == ButtonState.Released)
			{   
				this.selected.Clear();
			}

            oldKeyboardState = Keyboard.GetState();
            oldMouseState = Mouse.GetState();
            base.Update(gameTime);
        }
       
        public override void Draw(GameTime gameTime)
        {
						// Ordre de dessin : Tours --> Disques --> Plateau
            this.spriteBatch.Begin();
            this.drawModelTour();
            this.drawDisque();
            this.drawModelPlateau();
            this.spriteBatch.End();

            base.Draw(gameTime);
        }

        /// <summary>
        /// Dessine les disques sur les tours 
        /// </summary>
        public void drawDisque()
        {
						int decalage = 0; // Utile pour centrer les disques

            for (int i = 0; i < ((Game1)this.Game).hanoii.nbTower; i++)//pour chaque tour
            {
                for (int j = 0; j < ((Game1)this.Game).hanoii.GameStruct.ElementAt(i).Count; j++)//pour chaque disque
                {
                    //pour le positionnement
                    int scale = ((Game1)this.Game).hanoii.GameStruct.ElementAt(i).ElementAt(j).Rayon;
                    int pos = j - (((Game1)this.Game).hanoii.GameStruct.ElementAt(i).Count - (1 + ((Game1)this.Game).hanoii.nbDisk)) + this.cY;

                    //pour le dessin
                    spriteBatch.Draw(this.textureDisque, 
												new Rectangle(
																				(int)this.pTours.ElementAt(i).X -decalage - scale/2 -6,
																				pos*this.scaleY, 
																				scale*this.scaleX,
																				this.scaleY)
														, Color.Red);

										decalage += 7;

                }//fin du parcours des disque de la tour i

								decalage = 0;

            }//fin du parcour des tours
        }


        /// <summary>
        /// Dessine les tours du jeu
        /// </summary>
        private void drawModelTour()
        {
            this.pTours.Clear();
            for (int i = 0; i < ((Game1)this.Game).hanoii.nbTower; i++)
            {
                this.pTours.Add(new Vector2(this.cX + ((i) * ((Game1)this.Game).hanoii.nbDisk) * 3 * this.scaleX, this.cY * this.scaleY));
                this.spriteBatch.Draw(this.textureTour, 
										new Rectangle(
																		(int)this.pTours.ElementAt(i).X, 
																		(int)this.pTours.ElementAt(i).Y, 
																		this.scaleX, 
																		(((Game1)this.Game).hanoii.nbDisk + 1) * this.scaleY
																 ), Color.Green);
            }//fin du parcours des tours
        }


        /// <summary>
        /// Dessine la base rectangulaire comme plateau de jeu
        /// </summary>
        private void drawModelPlateau()
        {
            this.spriteBatch.Draw(this.texturePlateau,
								new Rectangle((int)this.pTours.ElementAt(0).X -50,
															(this.cY + ((Game1)this.Game).hanoii.nbDisk + 1) * this.scaleY,
															(int)this.pTours.ElementAt(this.pTours.Count - 1).X + this.scaleX + 50, // le 50 pour aller un peu plus loin que la derni�re tour
															this.scaleY), Color.Violet);																				// raison purement esth�tique			
        
				}

    }//fin de la classe

}//fin du namespace
