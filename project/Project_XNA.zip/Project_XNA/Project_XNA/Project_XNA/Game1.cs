using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Project_XNA
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        private GraphicsDeviceManager graphics;
        private SpriteBatch spriteBatch;
        private SpriteFont spriteFont;
        
        // �lement de dessin du jeu
        private DrawModel3D drawModel3d;
        private DrawModel2D drawModel2d;

        // �l�ment moteur du jeu
        public ModelHanoii hanoii;
        private Astar aetoile;
        private Stack<GameModel> path;
        public Stack<GameModel> history;

        // �l�ment de controle du jeu
        private KeyboardState old_KeyboardState;
        private bool resolved;
        private bool is3D;
        public int nbCoups;
        private double score;
 

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }


        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            //on d�finit les propri�t� de l'�cran
            this.graphics.IsFullScreen = false;
            this.graphics.PreferredBackBufferWidth = 800;
            this.graphics.PreferredBackBufferHeight = 600;
            this.graphics.ApplyChanges();

            //on cree le model de jeu Hanoii
            this.hanoii = new ModelHanoii(3, 5);    //3 tours et 5 disques
            this.hanoii.initFinal();
            this.path = new Stack<GameModel>();
            this.history = new Stack<GameModel>();

            //on creer le module de r�solution Aetoile
            this.aetoile = new Astar();

            //on cree les model de dessin
            this.drawModel2d = new DrawModel2D(this);
            this.drawModel3d = new DrawModel3D(this);

            //boolean de classe
            this.resolved = false;
            this.is3D = true;
            this.nbCoups = 0;

            //test primaire pour la selection de l'affichage
            if (is3D)
            {
                this.Components.Add(this.drawModel3d);
                this.Components.Add(this.drawModel3d.cible);
            }
            else
            {
                this.Components.Add(this.drawModel2d);
                this.Components.Add(this.drawModel2d.cible);
            }

            base.Initialize();
        }


        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteFont = this.Content.Load<SpriteFont>("Courrier New");
            // TODO: use this.Content to load your game content here

            base.LoadContent();
        }


        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here

            base.UnloadContent();
        }


        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                this.Exit();
            if (Keyboard.GetState().IsKeyDown(Keys.Enter) && this.hanoii.isFinish())
                this.Exit();

            // Commande pour la r�solution des tours de hanoii
            if (Keyboard.GetState().IsKeyDown(Keys.R) && !old_KeyboardState.IsKeyDown(Keys.R))
            {
                this.path = this.aetoile.getSolution(this.hanoii);
                this.resolved = true;
            }
            // Apres la r�solution faire espace pour faire d�filer les �tats jusqu'as la solution
            if (Keyboard.GetState().IsKeyDown(Keys.Space) && !old_KeyboardState.IsKeyDown(Keys.Space) && this.resolved && this.path.Count > 0) {
                    this.hanoii = (ModelHanoii)this.path.Pop();
            }

            //Commande pour change le mode 2D -> 3D 
            if (Keyboard.GetState().IsKeyDown(Keys.M) && !old_KeyboardState.IsKeyDown(Keys.M))
            {
                if (this.is3D)
                {
                    this.Components.Remove(this.drawModel3d);
                    this.Components.Remove(this.drawModel3d.cible);
                    this.Components.Add(this.drawModel2d);
                    this.Components.Add(this.drawModel2d.cible);
                    this.is3D = false;
                }
                else
                {
                    this.Components.Remove(this.drawModel2d);
                    this.Components.Remove(this.drawModel2d.cible);
                    this.Components.Add(this.drawModel3d);
                    this.Components.Add(this.drawModel3d.cible);
                    this.is3D = true;
                }
            }

            //on remet le coup d'avant
            if (Keyboard.GetState().IsKeyDown(Keys.LeftControl) && !old_KeyboardState.IsKeyDown(Keys.LeftControl))
            {
                if (this.history.Count > 0)
                {
                    this.hanoii = this.history.Pop() as ModelHanoii;
                    this.nbCoups++;
                }
            }


            if (!this.hanoii.isFinish()) {
                this.score = calculeScore(gameTime);
            }


            old_KeyboardState = Keyboard.GetState();

            base.Update(gameTime);
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            //on affiche un message de fin de jeu
            if (this.hanoii.isFinish())
            {
                spriteBatch.Begin();
                spriteBatch.DrawString(spriteFont, "Press Enter to leave", new Vector2(10, 10), Color.Red);
                spriteBatch.DrawString(spriteFont, "Score : "+((int)score), new Vector2(10, 30), Color.SaddleBrown);
                spriteBatch.End();
            }
            else
            {  //on affiche le nombre de coups depuis le debuts
                spriteBatch.Begin();
                spriteBatch.DrawString(spriteFont, "Nombres de coups / "+this.nbCoups, new Vector2(10, 10), Color.Green);
                spriteBatch.DrawString(spriteFont, "Temps ecoule / " + gameTime.TotalGameTime.Minutes + " : " + gameTime.TotalGameTime.Seconds, new Vector2(10, 30), Color.Green);
                spriteBatch.End();
            }

            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }

        private double calculeScore(GameTime gameTime) {
            return ((this.nbCoups * gameTime.TotalGameTime.TotalSeconds) / (this.hanoii.nbDisk * this.hanoii.nbTower));
        }

    }//fin de la classe
}//fin du namespace
