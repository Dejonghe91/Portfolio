using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace Project_XNA
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Disque : IComparable
    {
        private int rayon;
        public int Rayon
        {
            get { return this.rayon; }
        }


        private int coef;
        public int Coef {
            get { return this.coef;  }
            set { this.coef = value; }
        }

      
        private Rectangle place;
        public int X {
            get { return this.place.X;  }
            set { this.place.X = value; }
        }
        public int Y {
            get { return this.place.Y; }
            set { this.place.Y = value; }
        }
        public int Width {
            get { return this.place.Width; }
            set { this.place.Width = value; }
        }
        public int Height {
            get { return this.place.Height; }
            set { this.place.Height = value; }
        }


        public Disque(int r)
        {
            this.rayon = r;
        }


        /// <summary>
        /// Allow the component to be equalable with others
        /// </summary>
        /// <param name="obj"> a Disque object</param>
        /// <returns>true is object are similar , else return false</returns>
        public override bool Equals(object obj)
        {
            if (obj is Disque) {
                Disque d = obj as Disque;

                if (this.Rayon == d.Rayon)
                    return true;
                else
                    return false;
            }
            throw new ArgumentException("Object is not a disque");
        }
        
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }


        /// <summary>
        /// Allow the component to compare itself whit others
        /// </summary>
        /// <param name="obj">A Disque object</param>
        /// <returns>0 if they are equals, positive value if superior, else negative value</returns>
        public int CompareTo(object obj)
        {
            if (obj is Disque) {
                Disque d = obj as Disque;
                return this.Rayon - d.Rayon;
            }
            throw new ArgumentException("Object is not a disque");
        }

    }//fin de la classe
}//fin du namespace
