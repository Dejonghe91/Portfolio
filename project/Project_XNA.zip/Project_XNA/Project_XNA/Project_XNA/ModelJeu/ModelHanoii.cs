using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace Project_XNA
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class ModelHanoii : GameModel
    {
        private static ModelHanoii finalGame;

        private List<Stack<Disque>> gameStruct;     //structure des tours de hanoii
        public int nbTower, nbDisk;                 //infos sur le jeu


        public List<Stack<Disque>> GameStruct {
            get { return this.gameStruct;  }
            set { this.gameStruct = value; }
        }


        public ModelHanoii(int nbt, int nbd)
        {
            // TODO: Construct any child components here
            this.nbTower = nbt;
            this.nbDisk = nbd;
            initModel();
        }


        public ModelHanoii(ModelHanoii previousModel, List<Stack<Disque>> list)
        {
            this.nbDisk = previousModel.nbDisk;
            this.nbTower = previousModel.nbTower;
            this.gameStruct = copy(list);
        }


        /// <summary>
        /// M�thode pour initialiser le model a un d�but de partie
        /// </summary>
        private void initModel() 
        {
            gameStruct = new List<Stack<Disque>>();

            for (int i = 0; i < this.nbTower; i++) 
            {
                gameStruct.Add(new Stack<Disque>());
            }

            for (int i = 0; i < this.nbDisk; i++) 
            {
                gameStruct.ElementAt(0).Push(new Disque(nbDisk+1-i));
            }
        }//fin de initModel


        public void initFinal() 
        {
            finalGame = new ModelHanoii(nbTower, nbDisk);
            
            finalGame.gameStruct = new List<Stack<Disque>>();

            for (int i = 0; i < this.nbTower; i++) 
            {
                finalGame.gameStruct.Add(new Stack<Disque>());
            }

            for (int i = 0; i < this.nbDisk; i++) 
            {
                finalGame.gameStruct.ElementAt(finalGame.gameStruct.Count - 1).Push(new Disque(nbDisk + 1 - i));
            }
        }//fin de initModel
        
        
        /// <summary>
        /// Allow the game to move disque with the use of sp�cific operator
        /// </summary>
        /// <param name="element">The origin element</param>
        /// <returns>The list of all the possible moove</returns>
        public override List<GameModel> Evolve()
        {
            List<GameModel> future = new List<GameModel>();
            //on test toutes les combinaisons de d�placement possible
            for (int i = 0; i < nbTower; i++)
            {
                for (int j = 0; j < nbTower; j++)
                {
                    if (i != j && MoveOperator(i, j))                               //on ne bouge pas d'une case � elle meme ET on peut bouger 
                    {
                        List<Stack<Disque>> courant = copy(this.gameStruct);        // on copie la liste courante
                        courant.ElementAt(j).Push(courant.ElementAt(i).Pop());      // on effectue le mouvement de i -> j
                        future.Add(new ModelHanoii(this,courant));                  // on ajoute la copie modifier au future
                    }
                }
            }
            return future;
        }//fin de la m�thode evolve


        /// <summary>
        /// Allow to move disk to provide the tower of start and the tower of end
        /// </summary>
        /// <returns>the old game state</returns>
        public ModelHanoii moveTo(int dep, int ariv) {

            if (MoveOperator(dep, ariv)) {  //si le mouvement est effectuable 
                List<Stack<Disque>> courant = copy(this.gameStruct);                  // on copie la liste courante
                gameStruct.ElementAt(ariv).Push(gameStruct.ElementAt(dep).Pop());     //on effectue le mouvement sur le vrai model
                return new ModelHanoii(this, courant);                                                       //on retourne l'ancienne �tat pour en garder la trace
            }

            return null;
        }


        /// <summary>
        /// Permit to copy a List<Stack<int>> structure
        /// </summary>
        /// <param name="src">the structure to copy</param>
        /// <returns>the copy of src</returns>
        public List<Stack<Disque>> copy(List<Stack<Disque>> src)
        {
            List<Stack<Disque>> dest = new List<Stack<Disque>>(src.Count);

            foreach (Stack<Disque> sta in src)
            {
                Stack<Disque> staDest = new Stack<Disque>();
                Disque[] tab = new Disque[sta.Count];
                int j = 0;

                foreach (Disque d in sta)
                {
                    tab[j] = d; //besoin de copy dans disque ?
                    j++;
                }

                for (int k = tab.Length - 1; k >= 0; k--)
                {
                    staDest.Push(tab[k]);
                }

                dest.Add(staDest);
            }
            return dest;
        }


        /// <summary>
        /// Allow the game to inform that the disque can moove or not
        /// </summary>
        /// <param name="posDep">the numbre of the start tower</param>
        /// <param name="posFin">the numbre of the final tower</param>
        /// <returns>true id the disque can moove, else false</returns>
        private bool MoveOperator(int posDep, int posFin)
        {
            if (this.gameStruct.ElementAt(posDep).Count != 0) //teste si la tour de depart n'est pas vide
            {
                // Cas 1 : dest arriv� vide
                if (this.gameStruct.ElementAt(posFin).Count == 0)
                {
                    return true;
                }
                else   // Cas 2 : dest arriv� occupe -> test des rayons
                {
                    //si rayon occupe > rayon de depart
                    if (this.gameStruct.ElementAt(posFin).Peek().Rayon > this.gameStruct.ElementAt(posDep).Peek().Rayon)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }//fin de test de l'existance du disque � d�placer
            else
            {
                return false;
            }
        }//fin de la m�thode op�rator


        /// <summary>
        /// The key function to resolve the hanoii tower game
        /// </summary>
        /// <returns>a number like the distance to the solution</returns>
        public override int getHeuristique() 
        {
            int nb = 1;
            foreach (Stack<Disque> tour in GameStruct) {
                foreach (Disque disque in tour) {
                    disque.Coef = (tour.Count - disque.Rayon) + (nb - tour.Count);
                }
                nb++;
            } 
            return sommeCoefDisque();
        }


        private int sommeCoefDisque() {
            int somme = 0;
            foreach (Stack<Disque> tour in GameStruct)
            {
                foreach (Disque disque in tour)
                {
                    somme += disque.Coef;
                }
            }
            return somme;
        }


        /// <summary>
        /// Say if the game is the solution to the hanoii tower
        /// </summary>
        /// <returns>true if the game is solve, else return false</returns>
        public override bool isFinish()
        {
            return this.Equals(finalGame);
        }


        /// <summary>
        /// Know that two GameModel are equals or not
        /// </summary>
        /// <param name="obj">obj a GameModel</param>
        /// <returns>true if there are equals, esle return false</returns>
        public override bool Equals(object obj)
        {
            if (obj is GameModel)
            {
                ModelHanoii model = obj as ModelHanoii;

                if (model.nbDisk == this.nbDisk && model.nbTower == this.nbTower)
                {
                    for (int i = 0; i < this.nbTower; i++)
                    {
                        if (GameStruct.ElementAt(i).Count != model.GameStruct.ElementAt(i).Count)
                            return false;
                        else
                        {
                            for (int j = 0; j < GameStruct.ElementAt(i).Count; j++)
                            {
                                if (!GameStruct.ElementAt(i).ElementAt(j).Equals(model.GameStruct.ElementAt(i).ElementAt(j)))
                                    return false;
                            }
                        }
                    }
                    return true;
                }
                else return false;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            String str = "";

            for (int i = 0; i < nbTower; i++) {
                for (int j = 0; j < nbDisk; j++) {

                    if (this.gameStruct.ElementAt(i).Count > j)
                    {
                        str += this.gameStruct.ElementAt(i).ElementAt(j).Rayon;
                    }
                    else
                    {
                        str += "-"; 
                    }
                }
                str += "\n";
            }

            return str;
        }

    }//fin de la classe
}//fin du namespace
