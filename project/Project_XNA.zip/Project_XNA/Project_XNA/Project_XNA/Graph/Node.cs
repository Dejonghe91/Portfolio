﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_XNA
{
    class Node<T> : IComparable, IEquatable<T>
    {
        // atribut de la classe
        private static int idt = 0;
        private int id;
        private T data;

        //Accesseur
        public int ID {
            get { return this.id; }
        }

        public T Data {
            get { return this.data;  }
            set { this.data = value; }
        }

        public Node(T data) 
        {
            this.id = idt++;
            this.data = data;
        }

        /// <summary>
        /// Override the Equals by the id of the node
        /// </summary>
        /// <param name="obj">An object to compare</param>
        /// <returns>true if similar else false</returns>
        public override bool Equals(object obj)
        {
            if (obj is Node<T>) 
            {
                return this.ID == ((Node<T>)obj).ID && this.Equals(((Node<T>)obj).Data);
            }
            throw new ArgumentException("Object is not a node with the good type");
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public bool Equals(T other)
        {
            return this.Data.Equals(other);
        }
        
        public int CompareTo(object obj)
        {
            if (obj is Node<T>)
            {
                return this.ID - ((Node<T>)obj).ID;
            }
            else 
            {
                throw new ArgumentException("this object is note a node of the corect type");
            }
        }

    }//fin de la classe
}//fin du namespace
