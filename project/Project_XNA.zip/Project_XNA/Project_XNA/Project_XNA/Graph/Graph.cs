﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_XNA
{
    class Graph<T>
    {
        private List<Edge<Node<T>>> content;

        public Graph() {
            this.content = new List<Edge<Node<T>>>();
        }

        public void Add(Edge<Node<T>> edge) 
        {
            this.content.Add(edge);
        }

        public void Add(Node<T> parent, Node<T> child) 
        {
            //recherche de la node parent
            if (this.Contains(parent)) 
            {
                //ajout d'un new edge parent / enfant
                this.content.Add(new Edge<Node<T>>(parent, child));
            }
        }

        public void Add(T parent, T child)
        {
            //on crée les node
            Node<T> p = new Node<T>(parent);
            Node<T> c = new Node<T>(child);

            //recherche de la node parent
            if (this.Contains(p))
            {
                //ajout d'un new edge parent / enfant
                this.content.Add(new Edge<Node<T>>(p, c));
            }
        }

        public Edge<Node<T>> ElementAt(int id) 
        {
            try
            {
                return this.content.ElementAt(id);
            }catch(IndexOutOfRangeException exp)
            {
                exp.GetBaseException();
                return null;
            }
        }

        public int IndexOf(Edge<Node<T>> element) 
        {
            return this.content.IndexOf(element);
        }

        public int IndexOf(Node<T> uneNode) 
        {
            int i=0;
            foreach (Edge<Node<T>> edge in this.content)
            {
                if (edge.Contains(uneNode))
                { return i; }

                i++;
            }

            return -1;
        }

        public bool Contains(Node<T> uneNode) 
        {
            foreach (Edge<Node<T>> edge in this.content) 
            {
                if (edge.Contains(uneNode))
                { return true; }
            }

            return false;
        }


    }//fin de la classe
}//fin du namespace
