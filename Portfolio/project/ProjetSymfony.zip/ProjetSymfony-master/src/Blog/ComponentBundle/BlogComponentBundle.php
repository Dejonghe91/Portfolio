<?php

namespace Blog\ComponentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BlogComponentBundle extends Bundle
{
}
