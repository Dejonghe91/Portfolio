<?php

namespace Blog\AppBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BlogAppBundle extends Bundle
{
}
