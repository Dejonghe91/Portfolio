<?php

session_start(); 
$firstVisit = false; 
define('WEBROOT',trim(dirname($_SERVER['PHP_SELF']),'/')); 
if(!isset($_GET['p']) || !preg_match('/^[a-z]+$/',$_GET['p'])){ $_GET['p'] = 'admin';  $firstVisit = true;  }
if(!file_exists('content/'.$_GET['p'].'.php'))  $_GET['p'] = 'index'; 
$pages = array(
    'index' => 'Tableau de bord',
    'table' => 'Liste de mots',
    'recherche' => 'Recherche',
    'charts'=> 'Statistiques',
    'calendar'=>'Calendrier'
);
ob_start(); 
?><!DOCTYPE html>
<html>
    <head>
        <title>Thésaurus - Panneau Admin</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        
        
        <!-- Main stylesheed  (EDIT THIS ONE .. ou pas !!) -->
        <link rel="stylesheet" href="css/style.css" />
        
        <!-- jQuery AND jQueryUI -->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        
        <!-- jQuery Cookie - https://github.com/carhartl/jquery-cookie -->
        <script type="text/javascript" src="js/cookie/jquery.cookie.js"></script>
        
        <!-- jWysiwyg - https://github.com/akzhan/jwysiwyg/ -->
        <link rel="stylesheet" href="js/jwysiwyg/jquery.wysiwyg.old-school.css" />
        <script type="text/javascript" src="js/jwysiwyg/jquery.wysiwyg.js"></script>
        
        
        <!-- Tooltipsy - http://tooltipsy.com/ -->
        <script type="text/javascript" src="js/tooltipsy.min.js"></script>
        
        <!-- iPhone checkboxes - http://awardwinningfjords.com/2009/06/16/iphone-style-checkboxes.html -->
        <script type="text/javascript" src="js/iphone-style-checkboxes.js"></script>
        <script type="text/javascript" src="js/excanvas.js"></script>
        
        <!-- Load zoombox (lightbox effect) - http://www.grafikart.fr/zoombox -->
        <script type="text/javascript" src="js/zoombox/zoombox.js"></script>
        
        <!-- Charts - http://www.filamentgroup.com/lab/update_to_jquery_visualize_accessible_charts_with_html5_from_designing_with/ -->
        <script type="text/javascript" src="js/visualize.jQuery.js"></script>
        
        <!-- Uniform - http://uniformjs.com/ -->
        <script type="text/javascript" src="js/jquery.uniform.js"></script>
        
        
        <!-- Main Javascript that do the magic part (EDIT THIS ONE) -->
        <script type="text/javascript" src="js/main.js"></script>
        <?php
        /***/
        ?>
    </head>
    <body>
        
        <?php
            // Optionnel ..
            require 'content/settings/settings.php';
        ?>

        <!--              
                HEAD
                        --> 
        <div id="head">
            <div class="left">
                <a href="#" class="button profile"><img src="img/icons/top/huser.png" alt="" /></a>
                Bonjour, 
                <a href="#">Admin</a>
                |
                <a href="index.html">Logout</a>
            </div>
            <div class="right">
                <form action="admin.php?p=detail&" methode="GET" id="search" class="search placeholder">
                    <label>Recherche ?</label>
                    <input type="text" value="" name="q" class="text"/>
                    <input type="submit" value="rechercher" class="submit"/>
                </form>
            </div>
        </div>

        <!--            
                SIDEBAR
                         --> 
        <div id="sidebar">
            <ul>
                <li>
                    <a href="admin.php">
                        <img src="img/icons/menu/inbox.png" alt="" />
                        Tableau de bord 
                   </a>
                </li>
                <li<?php if(!$firstVisit): ?> class="current hover"<?php endif; ?>><a href="#"><img src="img/icons/menu/layout.png" alt="" /> Elements</a>
                    <ul>
                        <?php foreach($pages as $k=>$v): ?>
                        <li<?php if($k==$_GET['p']): ?> class="current"<?php endif; ?>><a href="admin.php?p=<?php echo $k; ?>"><?php echo $v; ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </li>
                
                <li><a href="#"><img src="img/icons/menu/brush.png" alt="" /> Ajout</a>
                    <ul>
                        <li><a href="admin.php?p=forms">Ajout de nouveau terme</a></li>
                        <ul>
                            <li><a href="admin.php?p=relation">Relation entre vedettes</a></li>
                            <li><a href="admin.php?p=relationassocie">Relation entre associes</a></li>
                        </ul>
                        </li>
                    </ul>
                </li>
                
                <li><a href="#"><img src="img/icons/menu/basket.png" alt="" /> Suppression</a>
                    <ul>
                        <li><a href="admin.php?p=suppression">Supprimer un terme</a></li>
                    </ul>
                </li>
                
            </ul>
            <a href="#collapse" id="menucollapse">&#9664; Réduire </a>

        </div>
                
        <!--            
              CONTENT 
                        --> 
                        
        <div id="content" class="white">
            <?php  if( isset($_GET['q']) ) : ?>
                   <?php require 'content/detail.php'; ?>
            <?php else: ?>
                <?php if($_GET['p'] == 'full'): ?>
                    <?php foreach($pages as $k=>$v): ?>
                        <?php require('content/'.$k.'.php'); ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <?php require('content/'.$_GET['p'].'.php'); ?>
                <?php endif; ?>
            <?php endif; ?>
            
        </div>
                        
    </body>
</html>
<?php
$content = ob_get_clean();
echo $content;
$content = str_replace('"img/','"../img/',$content);
$content = str_replace('"css/','"../css/',$content);
$content = str_replace('"js/','"../js/',$content);
$content = preg_replace('/admin.php\?p=([a-z]+)/','$1.html',$content);
file_put_contents('html/'.$_GET['p'].'.html', $content);
?>