<?php
    $login="system";
    $mdp="azerty";
    $host="localhost";
?>
