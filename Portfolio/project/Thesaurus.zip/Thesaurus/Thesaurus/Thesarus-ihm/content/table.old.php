<h1><img src="img/icons/posts.png" alt="" /> Liste de mots</h1>
<div class="bloc">
    <div class="title">
        Liste de mots
    </div>
    <div class="content">
        <table>
            <thead>
                <tr>
                    <th><input type="checkbox" class="checkall"/></th>
                    <th>Mot</th>
                    <th>Définition</th>
                    <th>Type</th>
                    <th>Parents</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php for($i=0; $i<10; $i++): ?>
                <tr>
                    <td><input type="checkbox" /></td>
                    <td><a href="#">Lorem ipsum</a></td>
                    <td><a href="#">Toto ...</a></td>
                    <td><a href="#">Dolor</a></td>
                    <td><a href="#">Consecte</a> , <a href="#">Adipiscin</a>, <a href="#">Elit</a></td>
                    <td class="actions"><a href="#" title="Edit this content"><img src="img/icons/actions/edit.png" alt="" /></a><a href="#" title="Delete this content"><img src="img/icons/actions/delete.png" alt="" /></a></td>
                </tr>
                <?php endfor; ?>
            </tbody>
        </table>
        <div class="left input">
            <select name="action" id="tableaction">
                <option value="">Action</option>
                <option value="delete">Delete</option>
            </select>
        </div>
        <div class="pagination">
            <a href="#" class="prev">«</a>
            <a href="#">1</a>
            <a href="#" class="current">2</a>
            ...
            <a href="#">21</a>
            <a href="#">22</a>
            <a href="#" class="next">»</a>
        </div>
    </div>
</div>

<div class="cb"></div>



