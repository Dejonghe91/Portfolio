<h1><img src="img/icons/posts.png" alt="" /> Liste de mots</h1>
<div class="bloc">
    <div class="title">
        Liste de mots
    </div>
	<?php
                require 'connect.php';


		$connect = oci_connect($login,$mdp,$host);
		
		$query=ociparse($connect,"select libelle from concept");
		oci_execute($query);
		$result=array();
		if($query!=false)
		{
			while(($tab=oci_fetch_array($query,OCI_BOTH)))
			{	
				$result[]=array($tab[0],"","Concept");
			}
		}
		$query=ociparse($connect,"select libelle,description from descripteurvedette");
		oci_execute($query);
		if($query!=false)
		{
			while(($tab=oci_fetch_array($query,OCI_BOTH)))
			{	
				$result[]=array($tab[0],$tab[1],"Descripteur vedette");
			}
		}
		$query=ociparse($connect,"select libelle from descripteurassocie");
		oci_execute($query);
		if($query!=false)
		{
			while(($tab=oci_fetch_array($query,OCI_BOTH)))
			{	
				$result[]=array($tab[0],"","Descripteur associe");
			}
		}
	?>
    <div class="content">
        <table>
			<thead>
				<tr>
					<!--<th><input type="checkbox" class="checkall"/></th>-->
					<th>Mot</th>
					<th>Définition</th>
					<th>Type</th>
					<!--<th>Parents</th>-->
				</tr>
			</thead>
			<tbody>
				<?php 
					foreach($result as $ligne)
					{
						echo "<tr><td><a href='detailterme.php?q=".$ligne[0]."'>".$ligne[0]."</a></td><td>".$ligne[1]."</td><td>".$ligne[2]."</td></tr>";
					}
				?>
				<!--<tr>
					<td><input type="checkbox" /></td>
					<td><a href="#">Lorem ipsum</a></td>
					<td><a href="#">Toto ...</a></td>
					<td><a href="#">Dolor</a></td>
					<td><a href="#">Consecte</a> , <a href="#">Adipiscin</a>, <a href="#">Elit</a></td>
				</tr>-->
			</tbody>
        </table>
        <!--<div class="left input">
            <select name="action" id="tableaction">
                <option value="">Action</option>
                <option value="delete">Delete</option>
            </select>
        </div>
        <div class="pagination">
            <a href="#" class="prev">«</a>
            <a href="#">1</a>
            <a href="#" class="current">2</a>
            ...
            <a href="#">21</a>
            <a href="#">22</a>
            <a href="#" class="next">»</a>
        </div>-->
    </div>
</div>

<div class="cb"></div>



