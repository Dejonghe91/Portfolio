<h1><img src="img/icons/posts.png" alt=""> Gestion de thésarus</h1>

<div class="bloc">
    <div class="title">Supprimer Mot</div>
    <div class="content">
        <div class="input medium">
            <label for="input1">Entrer le titre du Mot a supprimer</label>
            <input type="text" id="input-supp">
        </div>
        <div class="submit">
            <input type="submit" value="Supprimer" class="black">
        </div>
    </div>
    
</div>

<div class="cb"></div>

<div class="bloc left">
     <div class="title">Modification de Type </div>
     <div class="content">
         <div class="input">
            <label for="input1">Entrer le titre du Mot a modifier </label>
            <input type="text" id="input-type-modif">
        </div>
         <div class="input">
            <label for="select">Entrer le nouveau type pour le Mot</label>
            <select name="select" id="select">
                <option value="1">First value</option>
                <option value="2">Second value</option>
                <option value="3">Third value</option>
            </select>
        </div>
        <div class="submit">
            <input type="submit" value="Modifier">
        </div>
         
     </div>
   
</div>
<div class="bloc right">
     <div class="title">Modification de Parent </div>
     <div class="content">
         <div class="input">
            <label for="input1">Entrer le titre du Mot a modifier </label>
            <input type="text" id="input-parent-modif">
        </div>
         <div class="input">
            <label for="select">Entrer le nouveau parent pour le Mot</label>
            <select name="select" id="select-parent-modif">
                <option value="1">First value</option>
                <option value="2">Second value</option>
                <option value="3">Third value</option>
            </select>
        </div>
        <div class="submit">
            <input type="submit" value="Modifier">
        </div>
         
     </div>
   
</div>

<div class="cb"></div>

<div class="bloc left">
     <div class="title">Modification de Mot </div>
     <div class="content">
         <div class="input">
            <label for="input1">Entrer le titre du Mot a modifier </label>
            <input type="text" id="input-oldName">
        </div>
         <div class="input">
            <label for="input1">Entrer le nouveau nom pour le Mot</label>
            <input type="text" id="input-newName">
        </div>
        <div class="submit">
            <input type="submit" value="Modifier">
        </div>
         
     </div>
   
</div>

<div class="bloc right">
    <div class="title">Modification Définition</div>
    <div class="content">
        <div class="input">
            <label for="input1">Entrer le titre du Mot a modifier</label>
            <input type="text" id="input-modif-def">
        </div>
        <div class="input textarea">
            <label for="textarea1">Entrer la nouvelle definition pour le Mot</label>
            <textarea name="text" id="textarea-modif-def" rows="7" cols="4"></textarea>
        </div>
        <div class="submit">
            <input type="submit" value="Modifier">
        </div>
    </div>
</div>

<div class="cb"></div>
