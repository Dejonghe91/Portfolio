<h1><img src="img/icons/dashboard.png" alt="" /> Tableau de bord
</h1>
                
<div class="bloc left">
    <div class="title">
        Tableau de bord
    </div>
    <div class="content dashboard">
        <div class="center">
            <a href="admin.php?p=forms" class="shortcut">
                <img src="img/page.png" alt="" width="48" height="48"/>
                Ajouter un nouveau mot
            </a>
            <a href="admin.php?p=table" class="shortcut">
                <img src="img/contact.png" alt="" width="48" height="48" />
                Lister le thésaurus
            </a>
            <a href="admin.php?p=recherche" class="shortcut">
                <img src="img/icons/search.png" alt="" width="32" height="32" />
                Recherche
            </a>
            <a href="admin.php?p=calendar" class="shortcut">
                <img src="img/icons/calendar.png" alt=""  width="32" height="32"/>
                Calendar
            </a>
            
            <div class="cb"></div>
        </div>
    </div>
</div>


                
<div class="bloc right">
    <div class="title">
        Statistiques
    </div>
    <div class="content">
        <div class="left">
            <table class="noalt">
                <thead>
                    <tr>
                        <th colspan="2"><em>thésaurus</em></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><h4>46</h4></td>
                        <td class="good">Mots</td>
                    </tr>
                    <tr>
                        <td><h4>40</h4></td>
                        <td class="neutral">Descriptions</td>
                    </tr>
                    <tr>
                        <td><h4>5</h4></td>
                        <td>Concepts</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="right">
            <table class="noalt">
                <thead>
                    <tr>
                        <th colspan="2"><em>Groupes</em></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><h4>4</h4></td>
                        <td class="good">Utilisateurs</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="cb"></div>
    </div>
</div>

<div class="cb"></div>

<div class="bloc">
    <div class="title">Définitions</div>
    <div class="content">   
        <?php 
        $scripts = array(
            'cookie/jquery.cookie.js',
            'jwysiwyg/jquery.wysiwyg.js',
            'tooltipsy.min.js',
            'iphone-style-checkboxes.js',
            'excanvas.js',
            'zoombox/zoombox.js',
            'visualize.jQuery.js',
            'jquery.uniform.js',
            'main.js'
        ); 
        ?>
        <h5>Thésaurus ?!</h5>
        <p>
            Nous admettrons pour la suite du propos, qu'un vocabulaire partage ou thesaurus est
            une collection de concepts.<br/>
            Thesaurus en latin veut dire recueil, repertoire. C'est un outil linguistique qui permet
            de mettre en relation le langage naturel des utilisateurs et celui contenu dans les ressources
            (Source Wikipedia).<br/>
            Chaque concept est designe par un descripteur "vedette" qui est un terme ayant un
            libelle. Ce descripteur vedette peut etre relie a un ensemble de descripteurs, qui sont des
            termes, par diverses relations : synonymie, generalisation / specialisation et autres relations
            d'association.<br/><br/>
            <b>Exemple : </b>Le concept d'automobile est designe par le descripteur vedette automobile,
            celui ci est lie aux descripteurs synonymes voiture, caisse, tire ..<br/>
            Le descripteur vedette automobile est en relation de specialisation / generalisation avec
            les descripteurs vehicule a moteur (plus general) et decapotable (plus specique).<br/>
            Le descripteur voiture peut etre relie au descripteur vedette itineraire.
        </p>
    </div>
</div>
           

<div class="bloc">
    <div class="title">
        Raccourcis
    </div>
    <div class="content">
        <a href="admin.php?p=gestion" class="shortcut">
            <img src="img/icons/font.png" alt="" />
            Gestion
        </a>
        <a href="admin.php?p=table" class="shortcut">
            <img src="img/icons/window.png" alt=""  width="32" height="32"/>
            Liste
        </a>
        <a href="admin.php?p=forms" class="shortcut">
            <img src="img/icons/document-2-add.png" alt=""  width="32" height="32"/>
            Ajout
        </a>
        <a href="admin.php?p=charts" class="shortcut">
            <img src="img/icons/chart.png" alt=""  width="32" height="32"/>
            Statistiques
        </a>
        <a href="admin.php?p=calendar" class="shortcut">
            <img src="img/icons/calendar.png" alt=""  width="32" height="32"/>
            Calendrier
        </a>
        <div class="cb"></div>
    </div>
</div>