
<h1><img src="img/icons/calendar.png" alt="" /> Calendrier </h1>

<div class="bloc calendar">
    <div class="title"><a href="#" class="prev" title="Décembre 2013"></a>Janvier 2014<a href="#" class="next" title="Janvier 2014"></a></div>
    <div class="content">

        <table> 
            <thead> 
                <tr> 
                    <th>Lundi</th> 
                    <th>Mardi</th> 
                    <th>Mercredi</th> 
                    <th>Jeudi</th> 
                    <th>Vendredi</th> 
                    <th>Samedi</th> 
                    <th>Dimanche</th> 
                </tr> 
            </thead> 
            <tbody> 
                <tr> 
                    <td colspan="2" class="padding"></td> 
                    <td> 
                        <div class="day">1</div> 
                    </td> 
                    <td> 
                        <div class="day">2</div> 
                    </td>
                    <td> 
                        <div class="day">3</div> 
                    </td> 
                    <td> 
                        <div class="day">4</div> 
                    </td> 
                    <td> 
                        <div class="day">5</div> 
                    </td> 
                </tr><tr> 
                    <td> 
                            <div class="day">6</div> 
                    </td> 
                    <td> 
                            <div class="day">7</div> 
                    </td> 
                    <td> 
                            <div class="day">8</div> 
                    </td> 
                    <td class="today"> 
                            <div class="day">9</div> 
                            <ul class="events"> 
                                <li><span>15:00</span><a href="#">Soutenace !!!</a></li> 
                            </ul> 
                    </td>
                    <td> 
                            <div class="day">10</div> 
                    </td> 
                    <td> 
                            <div class="day">11</div> 
                    </td> 
                    <td> 
                            <div class="day">12</div> 
                    </td>
                </tr><tr> 
                    <td> 
                            <div class="day">13</div> 
                    </td> 
                    <td> 
                            <div class="day">14</div> 
                    </td> 
                    <td> 
                            <div class="day">15</div> 
                    </td> 
                    <td> 
                            <div class="day">16</div> 
                    </td>
                    <td> 
                            <div class="day">17</div> 
                    </td> 
                    <td> 
                            <div class="day">18</div> 
                    </td> 
                    <td> 
                            <div class="day">19</div> 
                    </td>
                </tr><tr> 
                    <td> 
                            <div class="day">20</div> 
                    </td> 
                    <td> 
                            <div class="day">21</div> 
                    </td> 
                    <td> 
                            <div class="day">22</div> 
                    </td> 
                    <td> 
                            <div class="day">23</div> 
                    </td>
                    <td> 
                            <div class="day">24</div> 
                    </td> 
                    <td> 
                            <div class="day">25</div> 
                    </td> 
                    <td> 
                            <div class="day">26</div> 
                    </td>
                </tr><tr> 
                    <td> 
                            <div class="day">27</div> 
                    </td> 
                    <td> 
                            <div class="day">28</div> 
                    </td> 
                    <td> 
                            <div class="day">29</div> 
                    </td> 
                    <td> 
                            <div class="day">30</div> 
                    </td>
                    <td> 
                            <div class="day">31</div> 
                    </td>
                </tr>
            </tbody> 
        </table>

    </div>
</div>