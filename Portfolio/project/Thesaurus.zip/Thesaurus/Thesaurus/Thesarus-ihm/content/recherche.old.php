<h1><img src="img/icons/posts.png" alt=""> Recherche </h1>

<div class="bloc">
    <div class="title">Rechercher un terme </div>
    <div class="content">
        <div class="input medium">
            <label for="input-search">Rechercher un terme dans le Thesaurus</label>
            <input type="text" id="input-search">
        </div>
       <a class="button" href="#"><img src="img/icons/menu/search.png"> Rechercher </a>
    </div>
    
</div>

<div class="cb"></div>