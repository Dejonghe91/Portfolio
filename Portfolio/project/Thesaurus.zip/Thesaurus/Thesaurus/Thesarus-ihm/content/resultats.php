<h1><img src="img/icons/posts.png" alt=""> Résultat de recherche pour : "terme"</h1>

<div class="bloc">
    <div class="title">Résultat de recherche </div>
    <div class="content">
        <table>
            <thead>
                <tr>
                    <th>Terme</th>
                    <th>Type</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><a href="#">Lorem ipsum</a></td>
                    <td><a href="#">Toto ...</a></td>
                </tr>
            </tbody>
        </table>
    </div>
    
</div>

<div class="cb"></div>