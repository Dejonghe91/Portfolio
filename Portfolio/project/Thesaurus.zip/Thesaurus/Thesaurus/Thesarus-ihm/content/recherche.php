<h1><img src="img/icons/posts.png" alt=""> Recherche </h1>

<div class="bloc">
    <div class="title">Rechercher un terme </div>
    <div class="content">
		<form method="get" action='admin.php'>
			<div class="input medium">
				<label for="input-search">Rechercher un terme dans le Thesaurus</label>
				<input type="text" id="input-search" name='q'>
			</div>
			<!-- <a class="button" href=""><img src="img/icons/menu/search.png"> Rechercher </a>-->
			<input type='submit' value='rechercher'>
	   </form>
    </div>
    
</div>

<div class="cb"></div>