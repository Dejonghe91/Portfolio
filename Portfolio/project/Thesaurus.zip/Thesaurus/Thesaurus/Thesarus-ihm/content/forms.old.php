<h1><img src="img/icons/posts.png" alt=""> Forms</h1>

<div class="bloc">
    <div class="title">Ajouter un nouveau Mot</div>
    <div class="content">
        <div class="input">
            <label for="input1">Entrer le titre du nouveau Mot a inserer</label>
            <input type="text" id="input1">
        </div>
        <div class="input textarea">
            <label for="textarea1">Entrer la nouvelle definition pour le Mot</label>
            <textarea name="text" id="textarea1" rows="7" cols="4"></textarea>
        </div>
        <div class="input">
            <label for="select">Entrer le type pour le Mot</label>
            <select name="select" id="select">
                <option value="1">First value</option>
                <option value="2">Second value</option>
                <option value="3">Third value</option>
            </select>
        </div>
        <div class="input">
            <label for="select">Entrer le nom du parent pour le Mot</label>
            <select name="select" id="select">
                <option value="1">First value</option>
                <option value="2">Second value</option>
                <option value="3">Third value</option>
            </select>
        </div>
        <div class="submit">
            <input type="submit" value="Enregistrer">
        </div>
    </div>
</div>

<div class="cb"></div>