<h1><img src="img/icons/posts.png" alt=""> Ajout de nouveau terme</h1>

<?php
	if(isset($_POST['valider']))
	{       
                $success = false;
		
                require 'connect.php';

		$connect = oci_connect($login,$mdp,$host);
		if($connect)
		{
			$stmt = oci_parse($connect, 
				"begin createConcept(:ajout,:descripteur,:description);
				end;");
				
			oci_bind_by_name($stmt, "ajout", $_POST['concept']);
			oci_bind_by_name($stmt, "descripteur", $_POST['descripteur']);

			oci_bind_by_name($stmt, "description", $_POST['description']);
			$r=oci_execute($stmt);
			if (!$r) {
				exit("Procedure Failed.");
			}
                        else{
                            $success = true;
                        }
		}
		else
		{
			echo "erreur de connection";
		}
	}
?>

<?php if( isset($success) && $success ): ?>
<div class="notif success bloc">
    <strong>Success :</strong> Terme ajouté au Thésaurus ! <a href="detailterme.php?<?php echo $_POST['concept'];?>">voir ...</a>
    <a href="#" class="close">x</a>
</div>
<div class="cb"></div>
<?php endif; ?>

<div class="bloc">
	<form method='post' action='#'>
		<div class="title">Ajouter un nouveau Mot</div>
		<div class="content">
			<div class="input">
				<label for="input1">Entrer le concept</label>
				<input type="text" id="input1" name='concept' required>
			</div>
			<div class="input">
				<label for="input1">Entrer le descripteur vedette</label>
				<input type="text" id="input2" name='descripteur' required>
			</div>
                        
			<div class="input textarea">
				<label for="textarea1">Entrer la nouvelle definition pour le Mot</label>
				<textarea name="description" id="textarea1" rows="7" cols="4" required></textarea>
			</div>
			<!--<div class="input">
				<label for="select">Entrer le type pour le Mot</label>
				<select name="select" id="select">
					<option value="1">First value</option>
					<option value="2">Second value</option>
					<option value="3">Third value</option>
				</select>
			</div>
			<div class="input">
				<label for="select">Entrer le nom du parent pour le Mot</label>
				<select name="select" id="select">
					<option value="1">First value</option>
					<option value="2">Second value</option>
					<option value="3">Third value</option>
				</select>
			</div>-->
			<div class="submit">
				<input type="submit" value="Enregistrer" name='valider'>
			</div>
		</div>
	</form>
</div>

<div class="cb"></div>