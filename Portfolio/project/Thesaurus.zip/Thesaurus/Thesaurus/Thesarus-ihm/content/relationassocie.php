<h1><img src="img/icons/posts.png" alt=""> Gestion de relations entre descripteurs associes</h1>

<?php
	
        require 'connect.php';

        $success = false;

	$connect = oci_connect($login,$mdp,$host);
	if($connect)
	{
		$query=oci_parse($connect,"select distinct libelle from descripteurvedette");
		oci_execute($query);
		if($query!=false)
		{
			while(($tab=oci_fetch_array($query,OCI_BOTH)))
			{	
				$descripteur[]=$tab[0];
			}
		}
		$query=oci_parse($connect,"select distinct libelle from descripteurassocie");
		oci_execute($query);
		if($query!=false)
		{
			while(($tab=oci_fetch_array($query,OCI_BOTH)))
			{	
				$associe[]=$tab[0];
			}
		}
	}
	else
	{
		echo "erreur de connection";
	}
	if(isset($_POST['valider']))
	{
		if($connect)
		{
			$stmt = oci_parse($connect, 
				"begin addRelationAssocie(:descripteur,:associe,:relation);
				end;");
				
			oci_bind_by_name($stmt, "descripteur", $_POST['descripteur']);
			oci_bind_by_name($stmt, "associe", $_POST['associe']);

			oci_bind_by_name($stmt, "relation", $_POST['relation']);
			$r=oci_execute($stmt);
			if (!$r) {
				exit("Procedure Failed.");
			}
                        else{
                            $success = TRUE;
                        }
		}
	}
	
?>

<?php if( isset($success) && $success ): ?>
<div class="notif success bloc">
    <strong>Success :</strong> Relation ajoutée au Thésaurus avec succés ! <a href="detailterme.php?<?php echo $_POST['descripteur1'];?>">voir ...</a>
    <a href="#" class="close">x</a>
</div>
<div class="cb"></div>
<?php endif; ?>

<div class="bloc">
	<form method='post' action='#'>
		<div class="title">Relier deux descripteurs associés</div>
		<div class="content">
			<div class="input">
				<label for="input1">Choississez le descripteur associé</label>
				<select name='descripteur'>
				<?php
					foreach($descripteur as $ligne)
					{
						echo "<option value='".$ligne."'>".$ligne."</option>";
					}
				?>
				</select>
			</div>
			<div class="input">
				<label for="input1">Choississez le descripteur associe</label>
				<select name='associe'>
				<?php
					foreach($associe as $ligne)
					{
						echo "<option value='".$ligne."'>".$ligne."</option>";
					}
				?>
				</select>
			</div>
                    
                         <script type="text/javascript">
                        $(function(){
                           $('#select-relation').change(function() {
                                //alert( $(this).val() ); // or $(this).val()
                                if( $(this).val() == 'autre' ){
                                    $('#select-relation-box').css('opacity', '0.5');
                                    $('#select-relation').attr('name', 'non-selected');
                                    $('#relat').attr('name', 'relation');
                                    $('#relat1').fadeIn();
                                }
                                else{
                                    $('#select-relation-box').css('opacity', '1');
                                    $('#select-relation').attr('name', 'relation');
                                    $('#relat').attr('name', 'non-relation');

                                    $('#relat1').fadeOut();
                                }
                            }); 
                        });
                    </script>
			<div class="input" id="select-relation-box">
				<label for="textarea1">Choisissez le nom de la relation</label>
                                <select name="relation" id="select-relation">
                                    <option value="S">Spécification</option>
                                    <option value="gen">Généralisation</option>
                                    <option value="autre">Autre</option>
                                </select>
			</div>
                       <div class="input" id="relat1" style="display: none;">
                            <label for="textarea1">Entrer le nom de la relation</label>
                            <input name="non-relation" id="relat" required>
			</div>
			<div class="submit">
				<input type="submit" value="Enregistrer" name='valider'>
			</div>
		</div>
	</form>
</div>

<div class="cb"></div>