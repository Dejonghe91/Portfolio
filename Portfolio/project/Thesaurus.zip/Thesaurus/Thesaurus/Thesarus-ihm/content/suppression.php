<h1><img src="img/icons/posts.png" alt=""> Forms</h1>

<?php
	
        require 'connect.php';


	$connect = oci_connect($login,$mdp,$host);
	if($connect)
	{
		$query=oci_parse($connect,"select distinct libelle from descripteurvedette");
		oci_execute($query);
		if($query!=false)
		{
			while(($tab=oci_fetch_array($query,OCI_BOTH)))
			{	
				$descripteur[]=$tab[0];
			}
		}
		$query=oci_parse($connect,"select distinct libelle from descripteurassocie");
		oci_execute($query);
		if($query!=false)
		{
			while(($tab=oci_fetch_array($query,OCI_BOTH)))
			{	
				$associe[]=$tab[0];
			}
		}
		$query=oci_parse($connect,"select distinct libelle from concept");
		oci_execute($query);
		if($query!=false)
		{
			while(($tab=oci_fetch_array($query,OCI_BOTH)))
			{	
				$concept[]=$tab[0];
			}
		}
	}
	else
	{
		echo "erreur de connection";
	}
	if(isset($_POST['valider']))
	{
		$stmt = oci_parse($connect, 
			"begin deleteconcept(:libelle);
			end;");
		oci_bind_by_name($stmt, "libelle", $_POST['concept']);
		$r=oci_execute($stmt);
		if (!$r) {
			exit("Procedure Failed.");
		}
	}
	if(isset($_POST['valider1']))
	{
		$stmt = oci_parse($connect, 
			"begin deletedescripteurvedette(:libelle);
			end;");
		oci_bind_by_name($stmt, "libelle", $_POST['descripteur']);
		$r=oci_execute($stmt);
		if (!$r) {
			exit("Procedure Failed.");
		}
	}
	if(isset($_POST['valider2']))
	{
		$stmt = oci_parse($connect, 
			"begin deletedescripteurassocie(:libelle);
			end;");
		oci_bind_by_name($stmt, "libelle", $_POST['associe']);
		$r=oci_execute($stmt);
		if (!$r) {
			exit("Procedure Failed.");
		}
	}
	
?>
<div class="bloc">
	
		<div class="title">Suppression de mot</div>
		<div class="content">
			<form method='post' action='#'>
			<div class="input">
				<label for="input1">Choississez le concept</label>
				<select name='concept'>
				<?php
					foreach($concept as $ligne)
					{
						echo "<option value='".$ligne."'>".$ligne."</option>";
					}
				?>
				</select>
			</div>
			<div class="submit">
				<input type="submit" value="Supprimer" name='valider'>
			</div>
			</form>
			<form method='post' action='#'>
			<div class="input">
				<label for="input1">Choississez le descripteur vedette</label>
				<select name='descripteur'>
				<?php
					foreach($descripteur as $ligne)
					{
						echo "<option value='".$ligne."'>".$ligne."</option>";
					}
				?>
				</select>
			</div>
			<div class="submit">
				<input type="submit" value="Supprimer" name='valider1'>
			</div>
			</form>
			<form method='post' action='#'>
			<div class="input">
				<label for="input1">Choississez le descripteur associe</label>
				<select name='associe'>
				<?php
					foreach($associe as $ligne)
					{
						echo "<option value='".$ligne."'>".$ligne."</option>";
					}
				?>
				</select>
			</div>
			<div class="submit">
				<input type="submit" value="Supprimer" name='valider2'>
			</div>
			</form>
		</div>
	</form>
</div>

<div class="cb"></div>