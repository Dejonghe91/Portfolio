<h1><img src="img/icons/posts.png" alt=""> Résultat de recherche pour</h1>

<div class="bloc">
    <div class="title">Résultat de recherche </div>
    <div class="content">
            <h3> Terme </h3>
            <p>Lorem ipsum dolor sit amet.</p>
            
            <h3> Défifnition </h3>
            <p>Lorem ipsum dolor sit amet.</p>
            
            <h3>Terme générique</h3>
            <p>Lorem ipsum dolor sit amet.</p>
            
            <h3>Termes spécifiques</h3>
            <p>Lorem ipsum dolor sit amet.</p>
    </div>
    
</div>

<div class="cb"></div>