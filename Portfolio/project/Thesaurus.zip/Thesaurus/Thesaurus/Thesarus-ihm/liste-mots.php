<?php
	require 'content/connect.php';

        $connect = oci_connect($login,$mdp,$host);

        $query=ociparse($connect,"select libelle from concept");
        oci_execute($query);
        $result=array();
        if($query!=false)
        {
                while(($tab=oci_fetch_array($query,OCI_BOTH)))
                {	
                        $result[]=array($tab[0],"","Concept");
                }
        }
        $query=ociparse($connect,"select libelle,description from descripteurvedette");
        oci_execute($query);
        if($query!=false)
        {
                while(($tab=oci_fetch_array($query,OCI_BOTH)))
                {	
                        $result[]=array($tab[0],$tab[1],"Descripteur vedette");
                }
        }
        $query=ociparse($connect,"select libelle from descripteurassocie");
        oci_execute($query);
        if($query!=false)
        {
                while(($tab=oci_fetch_array($query,OCI_BOTH)))
                {	
                        $result[]=array($tab[0],"","Descripteur associe");
                }
        }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Thésaurus  - Cinéma</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="js/jwysiwyg/jquery.wysiwyg.old-school.css" />

        <!-- jQuery AND jQueryUI -->
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.13/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/min.js"></script>
    </head>
    
    
    <body class="homeland">
        <div id="head">
            <div class="left">
                <a href="index.html" class="button profile"><img src="img/icons/top/huser.png" alt="" /></a>
                <a href="login.html">Connexion »</a>
            </div>
            <div class="right">
                <form action="#" id="search" class="search placeholder">
                    <label>Recherche ?</label>
                    <input type="text" value="" name="q" class="text"/>
                    <input type="submit" value="rechercher" class="submit"/>
                </form>
            </div>
        </div>
        
        <div id="content" style="margin-left: 28px;">
        <h1><img src="img/icons/posts.png" alt="" /> Liste de mots</h1>
            <div class="bloc">
                <div class="title">
                    Liste de mots
                </div>
                <div class="content">
                    <table>
                        <thead>
                            <tr>
                                <th>Mot</th>
                                <th>Définition</th>
                                <th>Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                foreach($result as $ligne)
                                {
                                        echo "<tr><td><a href='detailterme.php?q=".$ligne[0]."'>".$ligne[0]."</a></td><td>".$ligne[1]."</td><td>".$ligne[2]."</td></tr>";
                                }
                            ?>
                        </tbody>
                    </table>
                    <div class="pagination">
                        <a href="#" class="prev">«</a>
                        <a href="#" class="current">1</a>
                        ...
                        <a href="#" class="next">»</a>
                    </div>
                </div>
            </div>

            <div class="cb"></div>
        </div>
        
    </body>
</html>
