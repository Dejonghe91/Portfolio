Dia Diagram Editor
==================

Installation packages for Linux, MacOS X, and Windows are available

* http://live.gnome.org/Dia/Download
* http://dia-installer.de/