<?php
        require 'content/connect.php';


	$connect = oci_connect($login,$mdp,$host);
	if($connect)
{
	$mot=$_GET['q'];
	$query = ociparse($connect,"select libelle, description, deref(ref_concept).libelle from descripteurvedette where libelle like '%".$mot."%'");
	oci_execute($query);
	$result=array();
	if($query!=false)
	{
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{	
			if($tab[0]==$mot&&!isset($description))
			{
				$description = $tab[1];
			}
			$concept = $tab[2];
			$result[]=array($tab[0],'Descripteur vedette');
		}
	}
	$query = ociparse($connect,"select libelle from descripteurassocie where libelle like '%".$mot."%'");
	oci_execute($query);
	if($query!=false)
	{
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{	
			$result[]=array($tab[0],'Descripteur associe');
		}
	}
	$query = ociparse($connect,"select libelle from concept where libelle like '%".$mot."%'");
	oci_execute($query);
	if($query!=false)
	{
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{	
			$result[]=array($tab[0],'Descripteur associe');
		}
	}
	$query = ociparse($connect,"select deref(s.ref_descrip).libelle, s.nomrelation from table(select dv.spec_gen from descripteurvedette dv where dv.libelle='".$mot."') s");
	oci_execute($query);
	$relation=array();
	if($query!=false)
	{
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{	
			$relation[$tab[1]][]=array('Descripteur vedette',$tab[0]);
		}
	}
	$query = ociparse($connect,"select deref(s.ref_descrip).libelle, s.nomrelation from table(select dv.associes from descripteurvedette dv where dv.libelle='".$mot."') s");
	oci_execute($query);
	if($query!=false)
	{
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{
			$relation[$tab[1]][]=array('Descripteur associe',$tab[0]);
		}
	}
}
else
{
	echo "erreur de connection";	
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Thésaurus  - Cinéma</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="js/jwysiwyg/jquery.wysiwyg.old-school.css" />

        <!-- jQuery et jQueryUI -->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/min.js"></script>
    </head>
    <body>
    <div id="content" class="white">
<div class="bloc">
    <div class="title">Résultat de recherche pour : <?php echo $mot ?></div>
    <div class="content">
            <h3> Terme </h3>
            <?php
				if(sizeof($result)>0)
				{
					echo '<table>';
					foreach($result as $ligne)
					{
						echo '<tr><td><a href="./detailterme.php?q='.$ligne[0].'">'.$ligne[0].'</a></td><td><p> : '.$ligne[1].'</p></td></tr>';
					}
					echo '</table>';
				}
				else
				{
					echo "<p>Il n'y a aucun mot trouvé dans la base de données.</p>";
				}
            ?>
            
    </div>
    
</div>
        </div>

<div class="cb"></div>

</body>
</html>