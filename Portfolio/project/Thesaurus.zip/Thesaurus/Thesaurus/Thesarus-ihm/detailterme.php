<?php
        require 'content/connect.php';

	$connect = oci_connect($login,$mdp,$host);
	if($connect)
{
	$mot = htmlspecialchars($_GET['q']);
        
	$query = ociparse($connect,"select libelle, description, deref(ref_concept).libelle from descripteurvedette where libelle like '%".$mot."%'");
	oci_execute($query);
	$result=array();
	if($query!=false)
	{
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{	
			if($tab[0]==$mot&&!isset($description))
			{
				$description = $tab[1];
			}
			$concept = $tab[2];
			$result[]=array($tab[0],'Descripteur vedette');
		}
	}
	$query = ociparse($connect,"select libelle from descripteurassocie where libelle like '%".$mot."%'");
	oci_execute($query);
	if($query!=false)
	{
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{	
			$result[]=array($tab[0],'Descripteur associe');
		}
	}
	$query = ociparse($connect,"select libelle from concept where libelle like '%".$mot."%'");
	oci_execute($query);
	if($query!=false)
	{
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{	
			$result[]=array($tab[0],'Descripteur associe');
		}
	}
	$query = ociparse($connect,"select deref(s.ref_descrip).libelle, s.nomrelation from table(select dv.spec_gen from descripteurvedette dv where dv.libelle='".$mot."') s");
	oci_execute($query);
	$relation=array();
	if($query!=false)
	{
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{	
			$relation[$tab[1]][]=array('Descripteur vedette',$tab[0]);
		}
	}
	$query = ociparse($connect,"select deref(s.ref_descrip).libelle, s.nomrelation from table(select dv.associes from descripteurvedette dv where dv.libelle='".$mot."') s");
	oci_execute($query);
	if($query!=false)
	{
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{
			$relation[$tab[1]][]=array('Descripteur associe',$tab[0]);
		}
	}
}
else
{
	echo "erreur de connection";	
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Recherche : <?php if(isset($_GET['q'])) echo $_GET['q']; ?> - Thésaurus</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="js/jwysiwyg/jquery.wysiwyg.old-school.css" />

        <!-- jQuery et jQueryUI -->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/min.js"></script>
    </head>
    <body>
        
        <div id="head">
            <div class="left">
                <a href="admin.php" class="button profile"><img src="img/icons/top/huser.png" alt="" /></a>
            </div>
            <div class="right">
                <form action="detail.php" id="search" class="search placeholder">
                    <label>Recherche ?</label>
                    <input type="text" value="" name="q" class="text"/>
                    <input type="submit" value="rechercher" class="submit"/>
                </form>
            </div>
        </div>
        
    <div id="content" class="white">
        
<div class="bloc">
    <div class="title">Résultat de recherche pour : <?php echo $mot ?></div>
    <div class="content">
            <h5> Définition </h5>
            <?php
				if(isset($description))
				{
					echo '<p>'.$description.'</p>';
				}
				else
				{
					echo "<p>Il n'y a pas de définition pour ce mots</p>";
				}
?></div></div>
        
<?php if( isset($relation['gen'])): ?>
<div class="bloc">
    <div class="title">Résultat de recherche pour : <?php echo $mot ?></div>
    <div class="content">
                            <?php if(isset($relation['gen']))
				{
					echo "<table><thead><tr>";
					echo "<th>Terme générique</th><th>Type</th>";
					echo "</tr></thead>";
					foreach($relation['gen'] as $ligne)
					{
						echo '<tr><td><a href="./detailterme.php?q='.$ligne[1].'">'.$ligne[1].'</a></td><td><p> : '.$ligne[0].'</p></td></tr>';
					}
					echo '</table>';
					unset($relation['gen']);
				}
?></div></div> <?php endif; ?>
        
<?php if( isset($relation['S'])): ?>
<div class="bloc">
    <div class="title">Résultat de recherche pour : <?php echo $mot ?></div>
    <div class="content">
			<?php	if(isset($relation['S']))
				{
                                        echo "<table><thead><tr>";
					echo "<th>Terme synonyme</th><th>Type</th>";
					echo "</tr></thead>";
					foreach($relation['S'] as $ligne)
					{
						echo '<tr><td><a href="./detailterme.php?q='.$ligne[1].'">'.$ligne[1].'</a></td><td><p> : '.$ligne[0].'</p></td></tr>';
					}
					echo '</table>';
					unset($relation['S']);
				}
?></div></div> <?php endif; ?>
        
<?php if( isset($relation['A'])): ?>
<div class="bloc">
    <div class="title">Résultat de recherche pour : <?php echo $mot ?></div>
    <div class="content">
                        <?php if(isset($relation['A']))
				{
                                        echo "<table><thead><tr>";
					echo "<th>Terme antonyme</th><th>Type</th>";
					echo "</tr></thead>";
					foreach($relation['A'] as $ligne)
					{
						echo '<tr><td><a href="./detailterme.php?q='.$ligne[1].'">'.$ligne[1].'</a></td><td><p> : '.$ligne[0].'</p></td></tr>';
					}
					echo '</table>';
					unset($relation['A']);
				}
?></div></div> <?php endif; ?>
        
<?php if( isset($relation['spec'])): ?>
<div class="bloc">
    <div class="title">Résultat de recherche pour : <?php echo $mot ?></div>
    <div class="content">
                            <?php if(isset($relation['spec']))
				{
                                        echo "<table><thead><tr>";
					echo "<th>Terme spécifique</th><th>Type</th>";
					echo "</tr></thead>";
					foreach($relation['spec'] as $ligne)
					{
						echo '<tr><td><a href="./detailterme.php?q='.$ligne[1].'">'.$ligne[1].'</a></td><td><p> : '.$ligne[0].'</p></td></tr>';
					}
					echo '</table>';
					unset($relation['spec']);
				}
?></div></div> <?php endif; ?>
        
<?php if( sizeof($relation)>0 ): ?>
<div class="bloc">
    <div class="title">Résultat de recherche pour : <?php echo $mot ?></div>
    <div class="content">
                            <?php if(sizeof($relation)>0)
				{
                                        echo "<table><thead><tr>";
					echo "<th>Autres termes associés</th><th>Type</th>";
					echo "</tr></thead>";
					foreach($relation as $libelle=>$terme)
					{
						
						foreach($terme as $ligne)
						{
							echo '<tr><td><a href="./detailterme.php?q='.$ligne[1].'">'.$ligne[1].'</a></td><td><p> : '.$ligne[0].'</p></td></tr>';
						}
						
					}
                                        
                                        echo '</table>';
				}
			?>
    </div>
    
</div><?php endif; ?>
        </div>

<div class="cb"></div>

</body>
</html>