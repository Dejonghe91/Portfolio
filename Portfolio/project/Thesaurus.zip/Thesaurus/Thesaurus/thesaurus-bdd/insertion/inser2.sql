--synonymes du mot film 
insert into DescripteurAssocie values ('video');
insert into DescripteurAssocie values ('serie');
insert into DescripteurAssocie values ('annimation');
-- sequence d'image
--spec
insert into DescripteurAssocie values ('scene');
--equipement
insert into DescripteurAssocie values ('appareil');
-- camera
insert into DescripteurAssocie values ('appareil photo');
-- microphone
insert into DescripteurAssocie values ('micro');
--perche
insert into DescripteurAssocie values ('support de micro');
-- scenario
insert into DescripteurAssocie values ('script');

-- les concepts
insert into concept values ('ouvre de cinema', null);
	insert into concept values ('sequence d''image', null);
insert into concept values ('equipement', null);
	insert into concept values ('appareil de prise de vue', null);
	insert into concept values ('appareil de prise de son', null);
	insert into concept values ('perche', null);
insert into concept values ('scenario', null);

insert into DescripteurVedette values ( 'film', 
										'pellicule utilisee en photographie et au cinema', 
										(select ref(c) from concept c where c.libelle = 'ouvre de cinema'),
										listeDescripteurV(t_relationV('dirige','la fabrication d''un film est dirigee par un realisateur',(select ref(d) from descripteurvedette d 
										where d.libelle = 'realisateur')),
										t_relationV('produit','un film est produit par un producteur',(select ref(d) from descripteurvedette d 
										where d.libelle = 'producteur')),
										t_relationV('distribue','un film est distribue par un distributeur',(select ref(d) from descripteurvedette d 
										where d.libelle = 'distributeur')),
										t_relationV('joue','un acteur joue un role dans un film',(select ref(d) from descripteurvedette d 
										where d.libelle = 'acteur')),
										t_relationV('exploite','un film est exploite par un exploitant dans des salles de cinema',(select ref(d) from descripteurvedette d 
										where d.libelle = 'exploitant'))),
										listeDescripteurA(
										t_relationA('S',null,(select ref(d) from descripteurassocie d 
										where d.libelle = 'video')),
										t_relationA('S',null,(select ref(d) from descripteurassocie d 
										where d.libelle = 'serie')),
										t_relationA('S',null,(select ref(d) from descripteurassocie d 
										where d.libelle = 'annimation'))));

insert into DescripteurVedette values ( 'sequence d''image', 
										'suite de scenes, presentant chacune une unite de lieu', 
										(select ref(c) from concept c where c.libelle = 'sequence d''image'),
										listeDescripteurV(t_relationV('spec',null,(select ref(d) from descripteurvedette d 
										where d.libelle = 'film')),
										t_relationV('assemble','une sequnece d''image est assemblee par un monteur',(select ref(d) from descripteurvedette d 
										where d.libelle = 'monteur'))),
										listeDescripteurA(t_relationA('gen',null,(select ref(d) from descripteurassocie d 
										where d.libelle = 'scene'))));
										
insert into DescripteurVedette values ( 'scenario', 
										'description detaillee des scenes qui composeront un film', 
										(select ref(c) from concept c where c.libelle = 'scenario'),
										listeDescripteurV(t_relationV('ecrit','un scenario est ecrit par un scenariste',(select ref(d) from descripteurvedette d 
										where d.libelle = 'scenariste')),
										t_relationV('decrit','un scenario decrit un film',(select ref(d) from descripteurvedette d 
										where d.libelle = 'film'))),
										listeDescripteurA(t_relationA('S',null,(select ref(d) from descripteurassocie d 
										where d.libelle = 'script'))));

insert into DescripteurVedette values ( 'equipement', 
										'tout materiel necessaire a la fabrication d''un film ', 
										(select ref(c) from concept c where c.libelle = 'equipement'),
										null,
										listeDescripteurA(t_relationA('S',null,(select ref(d) from descripteurassocie d 
										where d.libelle = 'appareil'))));										
										
insert into DescripteurVedette values ( 'camera', 
										' appareil permettant de filmer, d''effectuer des prises de vues', 
										(select ref(c) from concept c where c.libelle = 'appareil de prise de vue'),
										listeDescripteurV(t_relationV('spec',null,(select ref(d) from descripteurvedette d 
										where d.libelle = 'equipement')),
										t_relationV('utilise','une camera est utilisee par un cameraman pour filmer',(select ref(d) from descripteurvedette d 
										where d.libelle = 'cameraman')),
										t_relationV('filme','une camera filme un film',(select ref(d) from descripteurvedette d 
										where d.libelle = 'film')),
										t_relationV('capture','une camera capture et enregistre des sequence d''image',(select ref(d) from descripteurvedette d 
										where d.libelle = 'sequence d''image'))),
										listeDescripteurA(t_relationA('S',null,(select ref(d) from descripteurassocie d 
										where d.libelle = 'appareil photo'))));										
										
insert into DescripteurVedette values ( 'microphone', 
										' appareil servant à transformer les vibrations sonores en impulsions electriques. Il sert a enregistrer et a amplifier le son', 
										(select ref(c) from concept c where c.libelle = 'appareil de prise de son'),
										listeDescripteurV(t_relationV('spec',null,(select ref(d) from descripteurvedette d 
										where d.libelle = 'equipement')),
										t_relationV('utilise','un microphone est utilisee par un perchman',(select ref(d) from descripteurvedette d 
										where d.libelle = 'perchman')),
										t_relationV('enregistre','un microphone enregistre le son d''un film',(select ref(d) from descripteurvedette d 
										where d.libelle = 'film'))),
										listeDescripteurA(t_relationA('S',null,(select ref(d) from descripteurassocie d 
										where d.libelle = 'micro'))));										
										
insert into DescripteurVedette values ( 'perche', 
										'bras porteur d''un micro au-dessus du champ filme', 
										(select ref(c) from concept c where c.libelle = 'perche'),
										listeDescripteurV(t_relationV('spec',null,(select ref(d) from descripteurvedette d 
										where d.libelle = 'equipement')),
										t_relationV('utilise','une perche est utilisee par un perchman',(select ref(d) from descripteurvedette d 
										where d.libelle = 'perchman')),
										t_relationV('porte','une perche porte un microphone',(select ref(d) from descripteurvedette d 
										where d.libelle = 'microphone'))),
										listeDescripteurA(t_relationA('S',null,(select ref(d) from descripteurassocie d 
										where d.libelle = 'support de micro'))));											

-- relation 'gen'
--film
insert into table (select dv.spec_gen from DescripteurVedette dv
		where dv.libelle ='film')
		values (t_relationV('gen',null,
		(select ref(d) from descripteurvedette d where d.libelle = 'sequence d''image')));		
--equipement
update 	DescripteurVedette dv set spec_gen
			=(listeDescripteurV(t_relationV('gen',null,(select ref(d) 
			from descripteurvedette d where d.libelle = 'camera'))))
		where dv.libelle = 'equipement';
insert into table (select dv.spec_gen from DescripteurVedette dv
		where dv.libelle ='equipement')
		values (t_relationV('gen',null,
		(select ref(d) from descripteurvedette d where d.libelle = 'microphone')));
insert into table (select dv.spec_gen from DescripteurVedette dv
		where dv.libelle ='equipement')
		values (t_relationV('gen',null,
		(select ref(d) from descripteurvedette d where d.libelle = 'perche')));

--relation autre
--film
insert into table (select dv.spec_gen from DescripteurVedette dv
		where dv.libelle ='film')
		values (t_relationV('filme','un filme est filme par une camera',
		(select ref(d) from descripteurvedette d where d.libelle = 'camera')));
insert into table (select dv.spec_gen from DescripteurVedette dv
		where dv.libelle ='film')
		values (t_relationV('enregistre','le son d''un film est enregistre par un microphone',
		(select ref(d) from descripteurvedette d where d.libelle = 'microphone')));	
insert into table (select dv.spec_gen from DescripteurVedette dv
		where dv.libelle ='film')
		values (t_relationV('decrit','un film est decrit par un scenario',
		(select ref(d) from descripteurvedette d where d.libelle = 'scenario')));
--monteur		
insert into table (select dv.spec_gen from DescripteurVedette dv
		where dv.libelle ='monteur')
		values (t_relationV('assemble','un monteur assemble des sequences d''image',
		(select ref(d) from descripteurvedette d where d.libelle = 'sequence d''image')));	
--realisateur
insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='realisateur')
			values (t_relationV('dirige','un realisateur dirige la fabrication d''un film',
			(select ref(d) from descripteurvedette d where d.libelle = 'film')));
--distributeur
insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='distributeur')
			values (t_relationV('distribue','un distributeur distribue un film',
			(select ref(d) from descripteurvedette d where d.libelle = 'film')));
--prod
			insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='producteur')
			values (t_relationV('produit','un producteur produit un film',
			(select ref(d) from descripteurvedette d where d.libelle = 'film')));
-- exploit
insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='exploitant')
			values (t_relationV('exploite','un exploitant exploite des films dans des salles de cinema',
			(select ref(d) from descripteurvedette d where d.libelle = 'film')));
--acteur
insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='acteur')
			values (t_relationV('joue','un acteur joue un role dans film',
			(select ref(d) from descripteurvedette d where d.libelle = 'film')));
--cameraman
insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='cameraman')
			values (t_relationV('utilise','un cameraman utilise la camera pour filmer',
			(select ref(d) from descripteurvedette d where d.libelle = 'camera')));
-- sequence
insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='sequence d''image')
			values (t_relationV('capture','une sequence d''image est capturee est enregistree par une camera',
			(select ref(d) from descripteurvedette d where d.libelle = 'camera')));
-- perchman
insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='perchman')
			values (t_relationV('utilise','un micophone est utilise par un perchman',
			(select ref(d) from descripteurvedette d where d.libelle = 'microphone')));
-- perchman
insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='perchman')
			values (t_relationV('utilise','une perche est utilise par un perchman',
			(select ref(d) from descripteurvedette d where d.libelle = 'perche')));
-- micro
insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='microphone')
			values (t_relationV('porte','un micophone est porte par une perche',
			(select ref(d) from descripteurvedette d where d.libelle = 'perche')));
-- scenariste
insert into table (select dv.spec_gen from DescripteurVedette dv
			where dv.libelle ='scenariste')
			values (t_relationV('ecrit','un scenariste ecrit un scenario',
			(select ref(d) from descripteurvedette d where d.libelle = 'scenario')));

--update concepts

update 	concept c set ref_descripteurVedette
			=(select ref(d)	from descripteurvedette d where d.libelle = 'film')
		where c.libelle = 'ouvre de cinema';
update 	concept c set ref_descripteurVedette
			=(select ref(d)	from descripteurvedette d where d.libelle = 'sequence d''image')
		where c.libelle = 'sequence d''image';
update 	concept c set ref_descripteurVedette
			=(select ref(d)	from descripteurvedette d where d.libelle = 'equipement')
		where c.libelle = 'equipement';
update 	concept c set ref_descripteurVedette
			=(select ref(d)	from descripteurvedette d where d.libelle = 'camera')
		where c.libelle = 'appareil de prise de vue';
update 	concept c set ref_descripteurVedette
			=(select ref(d)	from descripteurvedette d where d.libelle = 'microphone')
		where c.libelle = 'appareil de prise de son';
update 	concept c set ref_descripteurVedette
			=(select ref(d)	from descripteurvedette d where d.libelle = 'perche')
		where c.libelle = 'perche';
update 	concept c set ref_descripteurVedette
			=(select ref(d)	from descripteurvedette d where d.libelle = 'scenario')
		where c.libelle = 'scenario';