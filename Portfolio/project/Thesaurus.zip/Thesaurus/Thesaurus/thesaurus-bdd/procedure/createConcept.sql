--------------------------------------------------------
--  Fichier cr�� - jeudi-janvier-09-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure CREATECONCEPT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "PROJECT"."CREATECONCEPT" (nomConcept varchar, nomDescripteur varchar, description varchar) 
is
  descr_ok varchar(50);
  
  nom_concept exception;
    
  begin

      if nomConcept is not null then
        insert into CONCEPT values (nomConcept , null);
        createDescripteurVedette(nomDescripteur, description, nomConcept);
        update CONCEPT set ref_descripteurVedette = (select ref(c) from DescripteurVedette c where libelle = nomDescripteur) where libelle = nomConcept;
      else
        raise nom_concept;
      end if;
  
    COMMIT;

    EXCEPTION
    WHEN nom_concept then
        dbms_output.put_line('Le nom du concept est null');
    WHEN OTHERS THEN
            raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
            ROLLBACK;
  
end;

/
