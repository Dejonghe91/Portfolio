--------------------------------------------------------
--  Fichier cr�� - jeudi-janvier-09-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure DELETEDESCRIPTEURVEDETTE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "PROJECT"."DELETEDESCRIPTEURVEDETTE" (libelleDescr varchar)
AS 
  Cursor curseur is
    select deref(ref_descrip).libelle from table(select spec_gen from DescripteurVedette where libelle = libelleDescr);
  libelle_pointe varchar(50);
  null_arg exception;
BEGIN
  
  if libelleDescr is not null then
      open curseur;
        loop
          fetch curseur into libelle_pointe;
          exit when curseur%notfound;
          deleteRelationVedette(libelle_pointe, libelleDescr); 
        end loop;
      close curseur;
      delete from descripteurVedette where libelle = libelleDescr;
  else
    raise null_arg;
  end if;
  COMMIT;
  
  EXCEPTION
    WHEN null_arg then
        dbms_output.put_line('Le nom du descripteur est null');
    WHEN OTHERS THEN
            raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
            ROLLBACK;
END DELETEDESCRIPTEURVEDETTE;

/
