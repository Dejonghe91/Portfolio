--------------------------------------------------------
--  Fichier cr�� - jeudi-janvier-09-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure CREATEDESCRIPTEURVEDETTE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "PROJECT"."CREATEDESCRIPTEURVEDETTE" (nom varchar, description varchar, nomConcept varchar)
is
  -- les differents cas d'erreurs possible a gerer
  descr_existe exception;
  descr_nom_null exception;
  concept_null exception; 
  
begin
  
  if nomConcept is not null then
    if nom is not null then
      insert into descripteurVedette values (nom, 
                                             description,
                                             (select ref(c) from CONCEPT c where libelle = nomConcept), 
                                             listedescripteurV(), 
                                             listeDescripteurA());
    else
        raise descr_nom_null;
    end if;
  else 
    raise concept_null;
  end if;
  COMMIT;
   
   exception 
     WHEN descr_nom_null then
        dbms_output.put_line('Nom Manquant pour le descripteur');
     WHEN concept_null then
        dbms_output.put_line('Aucun concept a referencer pour le descripteur');
     WHEN OTHERS THEN
        raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
        ROLLBACK;
        
end;

/
