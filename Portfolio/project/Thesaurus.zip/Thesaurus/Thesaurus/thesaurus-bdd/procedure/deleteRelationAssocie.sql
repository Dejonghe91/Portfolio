--------------------------------------------------------
--  Fichier cr�� - jeudi-janvier-09-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure DELETERELATIONASSOCIE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "PROJECT"."DELETERELATIONASSOCIE" (libelleDescr varchar, libelleRef varchar) 
IS 
  null_args exception;
BEGIN 
  if libelleDescr is not null and libelleRef is not null then
    delete from table(select associes from descripteurVedette where libelle = libelleDescr) where deref(ref_descrip).libelle = libelleRef; 
  else
    raise null_args;
  end if;
  COMMIT;
  
  EXCEPTION
    WHEN null_args then
        dbms_output.put_line('Un des argument(s) est null');
    WHEN OTHERS THEN
            raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
            ROLLBACK;
END;

/
