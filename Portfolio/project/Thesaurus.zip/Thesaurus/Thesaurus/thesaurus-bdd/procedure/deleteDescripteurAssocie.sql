--------------------------------------------------------
--  Fichier cr�� - jeudi-janvier-09-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure DELETEDESCRIPTEURASSOCIE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "PROJECT"."DELETEDESCRIPTEURASSOCIE" (libelleDescr varchar)
IS 
  Cursor curseur is select libelle from descripteurVedette;
  libelle_pointe varchar(50);
  null_arg exception;

BEGIN
  if libelleDescr is not null then
    -- on supprime toute relation associe possible sur les descripteur vedette avec celui-ci
    open curseur;
      loop
        fetch curseur into libelle_pointe;
        exit when curseur%NOTFOUND;
        deleteRelationAssocie(libelle_pointe, libelleDescr);
      end loop;
    close curseur;
    
    delete from DESCRIPTEURASSOCIE where libelle = libelleDescr;
  else
    raise null_arg;
  end if;
  COMMIT;
  
  EXCEPTION
    WHEN null_arg then
        dbms_output.put_line('Le nom du descripteur est null');
    WHEN OTHERS THEN
            raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
            ROLLBACK;
END;

/
