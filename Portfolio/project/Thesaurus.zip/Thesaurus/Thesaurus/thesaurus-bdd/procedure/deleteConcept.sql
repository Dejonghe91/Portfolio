--------------------------------------------------------
--  Fichier cr�� - jeudi-janvier-09-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure DELETECONCEPT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "PROJECT"."DELETECONCEPT" (libelleConcept varchar) 
IS 
  libVedette varchar(50);
  null_arg exception;
BEGIN
  select deref(ref_descripteurVedette).libelle into libVedette from Concept where libelle = libelleConcept;

  if libelleConcept is not null then 
    deleteDescripteurVedette(libVedette);
    delete from CONCEPT where libelle = libelleConcept;  
  else
    raise null_arg;
  end if;
  COMMIT;
  
   EXCEPTION
    WHEN null_arg then
        dbms_output.put_line('Le nom du concept est null');
    WHEN OTHERS THEN
            raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
            ROLLBACK;
END;

/
