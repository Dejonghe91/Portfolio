--------------------------------------------------------
--  Fichier cr�� - jeudi-janvier-09-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure ADDRELATIONVEDETTE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "PROJECT"."ADDRELATIONVEDETTE" (nomRelation varchar ,libelleVedette varchar, libelleRef varchar)
IS 
  null_arg exception;
  
BEGIN
  if nomRelation is not null and libelleVedette is not null then
       insert into table (select dv.spec_gen from DescripteurVedette dv where dv.libelle = libelleVedette)
                  values (t_relationV(nomRelation, null, (select ref(d) from descripteurVedette d where d.libelle = libelleRef) )
                    ); 
       
       insert into table (select dv.spec_gen from DescripteurVedette dv where dv.libelle = libelleRef)
                  values (t_relationV(nomRelation, null, (select ref(d) from descripteurVedette d where d.libelle = libelleVedette) )
                    ); 
       
  else
    raise null_arg;
  end if;
  COMMIT;
  
  EXCEPTION
    WHEN null_arg then
        dbms_output.put_line('Un des argument(s) est null est null');
    WHEN OTHERS THEN
            raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
            ROLLBACK;
  
END;

/
