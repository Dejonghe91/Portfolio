-- creation du concept -> ConceptTest avec rvedette -> test1
execute createConcept('ConceptTest', 'test1', 'description test1');

-- cree descripteur vedette et associes
execute createDescripteurVedette('test2','description test2','ConceptTest');
execute createDescripteurVedette('test3','description test3','ConceptTest');

execute createDescripteurAssocie('assoc_test1');
execute createDescripteurAssocie('assoc_test2');

-- ajout des relationVedette sur test1 perche / camera / equipement
execute addRelationVedette('S', 'test1', 'perche');
execute addRelationVedette('S', 'test1', 'camera');
execute addRelationVedette('S', 'test1', 'equipement');
execute addRelationVedette('S', 'test1', 'test2');
execute addRelationVedette('S', 'test1', 'test3');

-- ajout des relationAssocie sur test1  sur scene et micre
execute addRelationAssocie('test1','assoc_test','gen');
execute addRelationAssocie('test1','scene','gen');
execute addRelationAssocie('test1','micro','autre');
execute addRelationAssocie('test1','assoc_test1','sup1');
execute addRelationAssocie('test1','assoc_test2','sup2');



-- delete
execute deleteRelationVedette('test1', 'camera');
execute deleteRelationVedette('test1', 'troubiboulga'); 

execute deleteRelationAssocie('test1', 'scene');
execute deleteRelationAssocie('test1', 'troubiboulga'); 

-- delete de descripteur vedette
execute deleteDescripteurVedette('test3');

execute deleteDescripteurAssocie('assoc_test1');

execute deleteConcept('ConceptTest');







