--------------------------------------------------------
--  Fichier cr�� - jeudi-janvier-09-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure CREATEDESCRIPTEURASSOCIE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "PROJECT"."CREATEDESCRIPTEURASSOCIE" (libelle varchar)
is
  libelle_null exception;
begin
  if libelle is not null then
    insert into descripteurAssocie values (libelle);
  else
    raise libelle_null;
  end if;
  COMMIT;
  
  EXCEPTION
    WHEN libelle_null then
        dbms_output.put_line('Le nom du descripteur associ� est null');
    WHEN OTHERS THEN
            raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
            ROLLBACK;
  
end;

/
