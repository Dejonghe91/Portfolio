--------------------------------------------------------
--  Fichier cr�� - jeudi-janvier-09-2014   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure ADDRELATIONASSOCIE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "PROJECT"."ADDRELATIONASSOCIE" (nomVedette varchar, nomAssocie varchar, nomRelation varchar)
AS 
  exist_row number;
  null_arg exception;
BEGIN 
  select count(*) into exist_row from descripteurAssocie where libelle = nomAssocie;
  
  if nomVedette is not null and nomAssocie is not null and nomRelation is not null then
      if exist_row > 0 then
        insert into table(select associes from descripteurVedette where libelle = nomVedette)
          values (t_relationA(nomRelation,
                              null,
                              (select ref(d) from DescripteurAssocie d where libelle = nomAssocie)
                  ));
      else
        CREATEDESCRIPTEURASSOCIE(nomAssocie);
        insert into table(select associes from descripteurVedette where libelle = nomVedette)
          values (t_relationA(nomRelation,
                              null,
                              (select ref(d) from DescripteurAssocie d where libelle = nomAssocie)
                  ));
      end if;
  else
    raise null_arg;
  end if;
  COMMIT;
  
  EXCEPTION
    WHEN null_arg then
        dbms_output.put_line('Un des argument(s) est null est null');
    WHEN OTHERS THEN
            raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
            ROLLBACK;

END ADDRELATIONASSOCIE;

/
