$login="system";
$mdp="1632";
$host="localhost";

$connect = oci_connect($login,$mdp,$host);

if($connect)
{
	OCIBindByName($connect,':p_mot',$_GET['q'],-1);
	$query = oci_parse($connect,"select libelle, description, deref(ref_concept).libelle from descripteurvedette where libelle like :p_mot");
	oci_execute(
	if($query==false)
	{
		echo "il n'y a pas de resultat";
	}
	else
	{
	
		while(($tab=oci_fetch_array($query,OCI_BOTH)))
		{	
			$description = $tab['1'];
			$conept = $tab[2];
		}
	}
}
else
{
	echo "erreur de connection";	
}
